# Sauve la princesse - version Pygame (v15)
# Les images du jeu sont dans le dossier images_jeu, qui doit rester à côté de ce fichier.
# Installation : pip install pygame        Lancement : python sauve_la_princesse.py (ou double-clic sur Jouer.bat)
#
# Nouveautés de la v15 : LE NOUVEAU LOOK
#  - fenêtre en 1280 x 720 (format 16:9), plus nette, surtout dans le navigateur
#  - les vraies images de Nicotch : la salle de la grotte, l'antre du dragon, l'écran titre, les 4 objets,
#    le prince, la princesse, les 4 mages, les 2 archers, le voleur, le spectre, le troll, le dragon (éveillé et endormi)
#  - le combat contre le dragon se passe dans son antre ; la victoire aussi, avec la princesse
#  - les personnages respirent, se penchent en attaquant, deviennent blancs quand ils sont touchés
#  - les torches de la salle vacillent
#  - (la source de vie et les épreuves gardent leurs décors dessinés par le code, en attendant leurs images)
#
# Nouveautés de la v14 : les SALLES D'ÉPREUVES (à la place de la plupart des salles vides)
#  - l'énigme de la porte : une devinette, 3 réponses au choix
#  - les pierres à runes : un jeu de mémoire, retrouve l'ordre dans lequel les pierres s'allument
#  - la fosse : un jeu de réflexes, saute quand le curseur passe dans la zone verte
#  Réussir rapporte une récompense : +1 PV, le repaire du dragon révélé sur la carte, ou +1 au prochain coup.
#  On peut passer une épreuve (F) et revenir plus tard. Sur la carte : coche verte = réussie, trait gris = ratée.
#
# Nouveautés de la v13 :
#  - combat au tour par tour : l'ennemi a une barre de vie ; à chaque tour tu choisis Attaquer, Parer,
#    Potion ou Fuir. Tu vois à l'avance s'il prépare un GROS COUP (!!) : pare-le avec ton bouclier !
#  - tout se joue à la souris : menus, entrées de la salle, boutons de combat, carte (le clavier marche toujours)
#  - nouveaux dessins des personnages (volume, ombres, reflets) et nouveaux mouvements : élan, coup d'épée,
#    parade au bouclier, flash quand l'ennemi est touché, souffle de feu du dragon, chute de l'ennemi vaincu
#  - le chevalier se place à gauche pendant un combat : il ne cache plus l'ennemi
#  - sprites.py n'est plus utilisé : les nouveaux dessins le remplacent

import array
import asyncio
import json
import math
import os
import random
import sys

import pygame


# Le même fichier marche sur PC ET dans un navigateur (avec pygbag). Dans le navigateur, sys.platform vaut "emscripten".
WEB = sys.platform == "emscripten"
L, H = 1280, 720         # taille de la fenêtre (format 16:9, comme un écran de télé)
HAUT_SCENE = 560         # la salle est au-dessus, la boîte de texte en dessous

SURPRISE_DRAGON = {"épée", "armure"}  # pour frapper le dragon endormi sans le réveiller

# Les 3 niveaux de difficulté. "salles" = combien de salles de chaque sorte (le total doit faire 24).
NIVEAUX = {
    "facile": {"nom": "Facile", "pv_max": 6, "desc": "Pour découvrir la grotte", "sommeil": 0.5,
               "salles": {"mage": 4, "vide": 2, "epreuve": 4, "ami": 2, "coeur": 5, "voleur": 3, "squelette": 2, "troll": 1, "dragon": 1}},
    "normal": {"nom": "Normal", "pv_max": 4, "desc": "L'aventure idéale", "sommeil": 0.35,
               "salles": {"mage": 4, "vide": 2, "epreuve": 3, "ami": 2, "coeur": 4, "voleur": 5, "squelette": 2, "troll": 1, "dragon": 1}},
    "difficile": {"nom": "Difficile", "pv_max": 3, "desc": "Pour les vrais chevaliers", "sommeil": 0.25,
                  "salles": {"mage": 4, "vide": 1, "epreuve": 2, "ami": 2, "coeur": 4, "voleur": 6, "squelette": 3, "troll": 1, "dragon": 1}},
}
# Face à un ennemi : combattre, surprendre ou fuir
ENNEMIS = ("voleur", "gardien", "dragon")
ACTIONS = ("combattre", "surprendre", "fuir")
RISQUE_FUITE = 0.8  # chance d'être touché dans le dos en fuyant un ennemi qui t'a vu
DEGATS_FUITE = 2  # coeurs perdus quand on est touché en fuyant
# Position (en x) des 3 entrées au fond de la salle, vue à la troisième personne
TUNNELS = {"gauche": 210, "haut": 615, "droite": 1037}
ORDRE_NIVEAUX = ("facile", "normal", "difficile")
GRILLE_L, GRILLE_H = 6, 4  # la grotte : 6 salles de large x 4 de haut = 24 salles
OBJETS = ("épée", "bouclier", "armure", "potion")
COULEURS_MAGES = {"épée": (120, 60, 170), "bouclier": (40, 120, 190),
                  "armure": (190, 100, 40), "potion": (50, 150, 110)}

# ---------------------------------------------------------------- Les salles
SALLES = [
    # 4 mages : chacun donne un objet
    {"type": "mage", "objet": "épée",
     "texte": "Un vieux mage à la barbe argentée sourit : « Prends cette épée magique, brave chevalier ! »"},
    {"type": "mage", "objet": "bouclier",
     "texte": "Un mage aux yeux brillants te tend un bouclier : « Il te protégera du feu du dragon. »"},
    {"type": "mage", "objet": "armure",
     "texte": "Un mage forgeron frappe son enclume : « Cette armure est faite pour toi, essaie-la ! »"},
    {"type": "mage", "objet": "potion",
     "texte": "Un mage tout en vert agite une fiole : « Cette potion te téléportera loin du danger. »"},
    # 5 salles vides
    {"type": "vide", "texte": "Une salle vide. Seule une toile d'araignée te regarde passer."},
    {"type": "vide", "texte": "Un couloir sombre où l'eau goutte du plafond. Rien ici."},
    {"type": "vide", "texte": "Une salle ronde avec une vieille fontaine à sec."},
    {"type": "vide", "texte": "Des ossements de rats jonchent le sol. Il ne se passe rien."},
    {"type": "vide", "texte": "Une grande salle silencieuse où ton écho te répond."},
    # 3 salles d'épreuves (mini-jeux) : une énigme, des pierres à runes (mémoire), une fosse (réflexes)
    {"type": "epreuve", "jeu": "enigme",
     "texte": "Une porte de pierre couverte d'inscriptions. Une voix grave résonne : « Réponds à mon énigme et mon trésor est à toi. »"},
    {"type": "epreuve", "jeu": "runes",
     "texte": "Quatre pierres gravées de runes brillent dans le noir. Un murmure : « Retiens l'ordre de la lumière... »"},
    {"type": "epreuve", "jeu": "fosse",
     "texte": "Une fosse profonde coupe la salle en deux. De l'autre côté, un coffre doré t'attend !"},
    # 2 amis
    {"type": "ami", "perso": "lutin",
     "texte": "Un jeune archer te fait signe : « Psst ! Pour vaincre le dragon, il te faut l'épée, l'armure ET le bouclier ! »"},
    {"type": "ami", "perso": "ancien",
     "texte": "Un vieil archer se repose : « Sans équipement face au dragon, seule la potion peut te sauver. Et méfie-toi des voleurs ! »"},
    # 4 sources de vie : +1 coeur, une seule fois chacune
    {"type": "coeur", "texte": "Une source scintillante jaillit d'un rocher. Un coeur de lumière flotte au-dessus de l'eau."},
    {"type": "coeur", "texte": "Un cristal rose en forme de coeur pulse doucement au centre de la salle."},
    {"type": "coeur", "texte": "Une fée minuscule t'offre un coeur de lumière : « Prends-le, tu en auras besoin ! »"},
    {"type": "coeur", "texte": "Un champignon géant et lumineux bat doucement comme un coeur. Son parfum te fait du bien."},
    # 5 voleurs
    {"type": "voleur", "texte": "Une ombre surgit dans ton dos : un VOLEUR !"},
    {"type": "voleur", "texte": "Un voleur masqué te bouscule en passant : un VOLEUR !"},
    {"type": "voleur", "texte": "Une main sort du mur et fouille ta besace : un VOLEUR !"},
    {"type": "voleur", "texte": "Un VOLEUR descend du plafond au bout d'une corde et attrape ton sac !"},
    {"type": "voleur", "texte": "Un VOLEUR à la grande cape te sourit : « Pas de pitié pour les aventuriers ! »"},
    # 3 mini-boss : 2 squelettes (2 dégâts) et 1 troll (3 dégâts)
    {"type": "gardien", "boss": "squelette", "degats": 2,
     "texte": "Un spectre encapuchonné se dresse, sa faux à la main : « Nul ne passe ! »"},
    {"type": "gardien", "boss": "squelette", "degats": 2,
     "texte": "Un spectre bleuté glisse hors de l'ombre en brandissant sa faux : « Retourne d'où tu viens ! »"},
    {"type": "gardien", "boss": "troll", "degats": 3,
     "texte": "Un TROLL des cavernes bloque le passage, son gourdin sur l'épaule : « Moi écraser toi ! »"},
    {"type": "gardien", "boss": "troll", "degats": 3,
     "texte": "Un énorme troll ouvre un oeil jaune et attrape son gourdin : « Qui réveille Gruk ? »"},
    # 1 dragon
    {"type": "dragon", "texte": "Le sol tremble... Le DRAGON se dresse devant toi, les yeux en feu !"},
]


def visiter(salle, jeu):
    """Effet des salles tranquilles : mage, ami, source de vie (et voleur quand on n'a rien à voler).
    Les ennemis (voleur, gardien, dragon) passent par agir : on choisit de combattre, surprendre ou fuir."""
    inv, anims = jeu["inv"], jeu["anims"]
    msg, typ = salle["texte"], salle["type"]

    def soigner():  # +1 coeur, avec le coeur qui vole vers la barre de vie
        jeu["pv"] += 1
        anims.append({"type": "soin", "duree": 1.2, "son": "ami", "montant": 1, "cible": jeu["pv"] - 1})

    if typ == "mage":
        objet = salle["objet"]
        if objet in inv:
            msg += f"\nTu as déjà : {objet}. Le mage te laisse repartir."
        else:
            inv.add(objet)
            msg += f"\n>>> Tu reçois : {objet} !"
            anims.append({"type": "don", "objet": objet, "duree": 1.2, "son": "don"})
    elif typ == "ami":
        if jeu["pv"] < jeu["pv_max"] and salle.get("pomme", True):
            salle["pomme"] = False  # une seule pomme par ami
            soigner()
            msg += "\n>>> Il te donne une pomme : +1 PV !"
    elif typ == "coeur":
        if not salle.get("source", True):
            msg += "\nLa source est tarie : tu as déjà pris son coeur."
        elif jeu["pv"] >= jeu["pv_max"]:
            msg += "\nTon coeur est déjà plein : reviens quand tu seras blessé."
        else:
            salle["source"] = False  # un seul coeur par source
            soigner()
            msg += "\n>>> Tu retrouves un coeur : +1 PV !"
    elif typ == "voleur":  # on n'a rien à voler
        return "voleur_parti", msg + "\nIl fouille tes poches... mais tu n'as rien ! Il repart bredouille."
    return "continuer", msg


# ---------------------------------------------------------------- Les salles d'épreuves (mini-jeux)
EPREUVES = ("enigme", "runes", "fosse")
NOMS_EPREUVES = {"enigme": "L'ÉNIGME DE LA PORTE", "runes": "LES PIERRES À RUNES", "fosse": "LA FOSSE"}
TEXTES_FAITS = {"enigme": "La porte de pierre est silencieuse. Son énigme a déjà été tentée.",
                "runes": "Les pierres à runes se sont éteintes pour toujours.",
                "fosse": "La fosse est toujours là, mais le coffre a déjà été ouvert."}
# Les énigmes : la question, puis la BONNE réponse en premier (les réponses sont mélangées dans le jeu)
ENIGMES = [
    ("Je suis plein de trous, mais je retiens quand même l'eau. Qui suis-je ?", "une éponge", "un seau", "un filet"),
    ("Qu'est-ce qui monte et qui descend sans jamais bouger ?", "un escalier", "un ascenseur", "un oiseau"),
    ("Plus je sèche, plus je suis mouillée. Qui suis-je ?", "une serviette", "une éponge", "la pluie"),
    ("J'ai des dents, mais je ne mords jamais. Qui suis-je ?", "un peigne", "un loup", "un crocodile"),
    ("Je parle sans bouche et je réponds sans oreilles. Qui suis-je ?", "l'écho", "le vent", "un fantôme"),
    ("Plus on m'enlève de terre, plus je deviens grand. Qui suis-je ?", "un trou", "un arbre", "une montagne"),
    ("Je cours sans jambes et j'ai un lit, mais je ne dors jamais. Qui suis-je ?", "une rivière", "un cheval", "le vent"),
    ("Il est à toi, mais les autres s'en servent bien plus que toi. Qu'est-ce que c'est ?", "ton prénom", "ton épée", "ta maison"),
    ("Le matin à quatre pattes, le midi sur deux, le soir sur trois. Qui est-ce ?", "l'homme", "le chien", "le dragon"),
    ("Un dragon a 3 têtes. Combien de têtes ont 4 dragons ?", "12", "7", "9"),
    ("Combien de mois de l'année ont 28 jours ?", "tous les 12", "un seul", "deux"),
    ("J'ai des aiguilles, mais je ne sais pas coudre. Qui suis-je ?", "une horloge", "une couturière", "un tailleur"),
]
COULEURS_RUNES = [(235, 75, 60), (70, 145, 245), (80, 205, 105), (245, 205, 60)]
GLYPHES = [  # le dessin gravé sur chaque pierre (des traits, autour du centre de la pierre)
    [((0, -26), (0, 26)), ((0, -26), (16, -10)), ((0, -4), (16, 12))],
    [((-12, -26), (-12, 26)), ((-12, -22), (12, 0)), ((12, 0), (-12, 22))],
    [((0, -26), (0, 26)), ((-16, -12), (16, 12)), ((16, -12), (-16, 12))],
    [((-15, 26), (0, -26)), ((0, -26), (15, 26)), ((-8, 6), (8, 6))],
]
# Selon la difficulté : longueur de la suite de runes, vitesse du curseur et largeur de la zone verte de la fosse
REGLAGES_EPREUVES = {"facile": {"runes": 3, "vitesse": 0.7, "zone": 0.26},
                     "normal": {"runes": 4, "vitesse": 0.95, "zone": 0.2},
                     "difficile": {"runes": 5, "vitesse": 1.2, "zone": 0.15}}
DEBUT_RUNES, PAS_RUNES, ALLUMAGE = 0.8, 0.8, 0.5  # la démonstration : attente, écart entre 2 pierres, durée d'allumage


def commencer_epreuve(jeu, salle):
    """On entre dans une salle d'épreuve : on prépare le mini-jeu. Retourne le message à afficher."""
    sorte = salle["jeu"]
    reglage = REGLAGES_EPREUVES[jeu["niveau"]]
    ep = {"jeu": sorte, "debut": None}
    if sorte == "enigme":
        vues = jeu.setdefault("enigmes_vues", set())
        restantes = [i for i in range(len(ENIGMES)) if i not in vues] or list(range(len(ENIGMES)))
        i = random.choice(restantes)
        vues.add(i)
        question, *reponses = ENIGMES[i]
        bonne = reponses[0]
        random.shuffle(reponses)
        ep.update(question=question, choix=reponses, bonne=reponses.index(bonne))
        aide = "Réponds bien et gagne une récompense !"
    elif sorte == "runes":
        suite = []
        for _ in range(reglage["runes"]):  # jamais deux fois la même pierre de suite : plus facile à suivre
            suite.append(random.choice([k for k in range(4) if not suite or k != suite[-1]]))
        ep.update(suite=suite, saisie=[], appui=None)
        aide = "Retiens l'ordre des pierres et gagne une récompense !"
    else:
        ep.update(vitesse=reglage["vitesse"], largeur=reglage["zone"], centre=random.uniform(0.3, 0.7))
        aide = "Saute au bon moment et le trésor est à toi !"
    jeu["epreuve"] = ep
    jeu["phase"] = "epreuve"
    return salle["texte"] + "  " + aide


def rune_allumee(ep, t):
    """Pendant la démonstration des runes : (pierre allumée ou None, numéro de l'étape, démonstration finie ?)."""
    if ep["debut"] is None:
        return None, -1, False
    dt = t - ep["debut"] - DEBUT_RUNES
    if dt < 0:
        return None, -1, False
    k = int(dt // PAS_RUNES)
    if k >= len(ep["suite"]):
        return None, k, True
    return (ep["suite"][k] if dt - k * PAS_RUNES < ALLUMAGE else None), k, False


def curseur_fosse(ep, t):
    """Position du curseur de la fosse, de 0 (à gauche) à 1 (à droite) : il fait des allers-retours."""
    if ep["debut"] is None:
        return 0.0
    phase = ((t - ep["debut"]) * ep["vitesse"]) % 2
    return phase if phase < 1 else 2 - phase


def epreuve_active(jeu):
    """Vrai si on peut jouer au mini-jeu maintenant (pas pendant une animation)."""
    return jeu.get("etat") == "jeu" and jeu.get("phase") == "epreuve" and jeu.get("epreuve") and not jeu["anims"]


def repondre_enigme(jeu, i):
    if not epreuve_active(jeu) or jeu["epreuve"]["jeu"] != "enigme":
        return
    ep = jeu["epreuve"]
    choisi, bonne = ep["choix"][i], ep["choix"][ep["bonne"]]
    if i == ep["bonne"]:
        finir_epreuve(jeu, True, f"« {choisi.capitalize()} ! » La voix éclate de rire : « Bien répondu ! » La porte s'ouvre.")
    else:
        finir_epreuve(jeu, False, f"« {choisi.capitalize()} ? » Raté ! La bonne réponse était : {bonne}. La porte reste fermée.")


def toucher_rune(jeu, i):
    if not epreuve_active(jeu) or jeu["epreuve"]["jeu"] != "runes":
        return
    ep, t = jeu["epreuve"], jeu.get("t", 0.0)
    if not rune_allumee(ep, t)[2]:
        return  # on attend la fin de la démonstration
    ep["appui"] = (i, t)
    jouer_son("ami")
    if i != ep["suite"][len(ep["saisie"])]:
        finir_epreuve(jeu, False, "Raté ! Ce n'était pas la bonne pierre. Elles grondent et s'éteignent.")
        return
    ep["saisie"].append(i)
    if len(ep["saisie"]) == len(ep["suite"]):
        finir_epreuve(jeu, True, "Les quatre pierres s'illuminent ensemble : bravo, tu as retenu toute la suite !")


def sauter_fosse(jeu):
    if not epreuve_active(jeu) or jeu["epreuve"]["jeu"] != "fosse":
        return
    ep = jeu["epreuve"]
    reussi = abs(curseur_fosse(ep, jeu.get("t", 0.0)) - ep["centre"]) <= ep["largeur"] / 2
    jeu["anims"].append({"type": "saut", "duree": 0.9, "son": "pas", "reussi": reussi})
    if reussi:
        finir_epreuve(jeu, True, "Hop ! Tu t'élances et tu atterris de l'autre côté, juste devant le coffre !")
    else:
        blesser(jeu, 1, mortel=False)  # on ne meurt pas dans la fosse : il reste toujours au moins 1 PV
        finir_epreuve(jeu, False, "Trop tôt... ou trop tard ! Tu tombes dans la fosse et tu remontes en t'égratignant : -1 PV.")


def passer_epreuve(jeu):
    """On laisse le mini-jeu de côté : la salle garde son épreuve, on pourra revenir la tenter."""
    if epreuve_active(jeu):
        finir_epreuve(jeu, None, "Tu préfères ne pas tenter ta chance... pour l'instant. Tu pourras revenir plus tard.")


def finir_epreuve(jeu, reussi, texte):
    """Fin du mini-jeu. reussi : True (gagné), False (raté), None (passé, on pourra revenir)."""
    salle = jeu["grotte"][jeu["pos"]]
    sorte = jeu["epreuve"]["jeu"]
    jeu["epreuve"], jeu["phase"] = None, "carrefour"
    if reussi is not None:  # tentée : la salle ne proposera plus son épreuve
        salle.update(fait=True, reussi=reussi, texte=TEXTES_FAITS[sorte])
        jeu["anims"].append({"type": "reussite" if reussi else "rate", "duree": 1.1, "son": "don" if reussi else None})
        if reussi:
            texte += "\n" + recompense(jeu)
    jeu["msg"] = texte


def recompense(jeu):
    """Ce que rapporte une épreuve réussie : +1 PV, le dragon révélé sur la carte, ou +1 au prochain coup."""
    choix = []
    if jeu["pv"] < jeu["pv_max"]:
        choix.append("soin")
    case_dragon = next(c for c, s in jeu["grotte"].items() if s["type"] == "dragon")
    if case_dragon not in jeu["vus"]:
        choix.append("carte")
    if not jeu.get("force"):
        choix.append("force")
    sorte = random.choice(choix or ["force"])
    if sorte == "soin":
        jeu["pv"] += 1
        jeu["anims"].append({"type": "soin", "duree": 1.2, "son": "ami", "montant": 1, "cible": jeu["pv"] - 1})
        return ">>> Récompense : une pomme dorée ! +1 PV."
    if sorte == "carte":
        jeu["vus"].add(case_dragon)
        return ">>> Récompense : un vieux parchemin ! Le repaire du DRAGON est marqué sur ta carte (C)."
    jeu["force"] = 1
    return ">>> Récompense : une pierre de force ! Ton prochain coup en combat fera +1."


# Les touches du clavier pour les mini-jeux. Sur un clavier AZERTY, la rangée du haut donne & é " ' sans Maj.
CHIFFRES = {"1": 0, "&": 0, "2": 1, "é": 1, "3": 2, '"': 2, "4": 3, "'": 3}


def touche_epreuve(jeu, ev):
    sorte = jeu["epreuve"]["jeu"]
    pave = {pygame.K_KP1: 0, pygame.K_KP2: 1, pygame.K_KP3: 2, pygame.K_KP4: 3}
    chiffre = pave.get(ev.key, CHIFFRES.get(getattr(ev, "unicode", "") or "", None))
    if ev.key == pygame.K_f:
        passer_epreuve(jeu)
    elif sorte == "enigme" and chiffre is not None and chiffre < 3:
        repondre_enigme(jeu, chiffre)
    elif sorte == "runes" and chiffre is not None:
        toucher_rune(jeu, chiffre)
    elif sorte == "fosse" and ev.key in (pygame.K_SPACE, pygame.K_RETURN):
        sauter_fosse(jeu)


# ---------------------------------------------------------------- Classement
DOSSIER = os.path.dirname(os.path.abspath(__file__))


def fichier_classement(niveau):
    """Chaque niveau de difficulté a son propre classement."""
    return os.path.join(DOSSIER, f"classement_{niveau}.json")


def memoire_navigateur():
    """Dans le navigateur, on range le classement dans sa mémoire (localStorage) : il reste après un rechargement."""
    if not WEB:
        return None
    try:
        import platform as plateforme  # avec pygbag, ce module donne accès à la page web (window)
        return plateforme.window.localStorage
    except Exception:
        return None


def charger_classement(niveau):
    try:
        memoire = memoire_navigateur()
        if memoire is not None:
            texte = memoire.getItem(f"sauve_la_princesse_{niveau}")
            return json.loads(texte) if texte else []
        with open(fichier_classement(niveau), "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:  # pas encore de classement, ou fichier abîmé : on repart de zéro
        return []


def envoyer_score_site(coups, niveau):
    """Envoie la victoire au tableau des scores en ligne de www.nicotch.fr (version navigateur seulement)."""
    if not WEB:
        return
    message = json.dumps({"source": "nicotch-jeu", "type": "score", "score": int(coups), "variante": niveau})
    try:
        import platform as plateforme
        plateforme.window.eval("window.parent.postMessage(" + message + ", '*')")
    except Exception:
        try:
            import platform as plateforme
            plateforme.window.parent.postMessage(plateforme.window.JSON.parse(message), "*")
        except Exception:
            print("Score non envoyé au site.")


def enregistrer(nom, coups, niveau):
    """Ajoute la victoire au classement du niveau (moins de coups = mieux). Retourne le rang."""
    classement = charger_classement(niveau)
    entree = {"nom": nom, "coups": coups}
    classement.append(entree)
    classement.sort(key=lambda j: j["coups"])
    classement = classement[:50]  # on garde les 50 meilleurs
    rang = classement.index(entree) + 1 if entree in classement else len(classement) + 1
    try:
        memoire = memoire_navigateur()
        if memoire is not None:
            memoire.setItem(f"sauve_la_princesse_{niveau}", json.dumps(classement, ensure_ascii=False))
        else:
            with open(fichier_classement(niveau), "w", encoding="utf-8") as f:
                json.dump(classement, f, ensure_ascii=False, indent=2)
    except Exception:
        print("Impossible d'enregistrer le classement.")
    envoyer_score_site(coups, niveau)
    return rang


# ---------------------------------------------------------------- Sons
# Les bruitages sont fabriqués par le code : une note = une fréquence (en Hz) pendant une durée.
FREQ_SON = 22050
SONS = {}
SON_ACTIF = True


def note(freq, duree, volume=0.4, glisse=0, bruit=0.0):
    """Une note qui peut monter ou descendre (glisse) et être mélangée à du bruit (bruit de 0 à 1)."""
    n = int(FREQ_SON * duree)
    phase, notes = 0.0, []
    for i in range(n):
        phase += 2 * math.pi * (freq + glisse * i / n) / FREQ_SON
        v = math.sin(phase) * (1 - bruit) + random.uniform(-1, 1) * bruit
        enveloppe = min(1, i / 150) * (1 - i / n)  # attaque rapide, puis le son s'éteint
        notes.append(v * volume * enveloppe)
    return notes


def melodie(*notes_):
    """Enchaîne des notes (freq, durée). Une fréquence 0 = un silence."""
    resultat = []
    for freq, duree in notes_:
        resultat += note(freq, duree, 0.35 if freq else 0)
    return resultat


def fabriquer(echantillons):
    donnees = array.array("h", [int(max(-1, min(1, v)) * 32767) for v in echantillons])
    return pygame.mixer.Sound(buffer=donnees.tobytes())


def init_sons():
    """Prépare tous les bruitages. Si l'ordinateur n'a pas de carte son, le jeu marche quand même (sans son)."""
    try:
        pygame.mixer.quit()
        # Dans le navigateur, une plus grande réserve de son (buffer) évite les grésillements quand l'image est longue à dessiner
        pygame.mixer.init(FREQ_SON, -16, 1, buffer=2048 if WEB else 512, allowedchanges=0)
        SONS.update({
            "pas": fabriquer(note(120, 0.07, 0.5, glisse=-40, bruit=0.5)),
            "don": fabriquer(melodie((523, .09), (659, .09), (784, .09), (1047, .25))),
            "vol": fabriquer(note(600, 0.45, 0.35, glisse=-450, bruit=0.1)),
            "coup": fabriquer(note(350, 0.3, 0.5, glisse=-300, bruit=0.6)),
            "degats": fabriquer(note(120, 0.4, 0.7, glisse=-70, bruit=0.5)),
            "dragon": fabriquer(note(70, 1.0, 0.7, glisse=40, bruit=0.7)),
            "gardien": fabriquer(note(220, 0.5, 0.4, bruit=0.9)),
            "ami": fabriquer(note(700, 0.15, 0.3, glisse=350)),
            "fuite": fabriquer(note(300, 0.7, 0.3, glisse=900, bruit=0.2)),
            "victoire": fabriquer(melodie((523, .15), (523, .15), (523, .15), (659, .3), (587, .15), (784, .45),
                                          (0, .35), (1100, .08), (1400, .12))),
            "mort": fabriquer(melodie((392, .3), (330, .3), (262, .3), (196, .8))),
        })
        for son in SONS.values():
            son.set_volume(0.7)
    except Exception:
        SONS.clear()
        print("Pas de son disponible : le jeu continue en silence.")


def jouer_son(nom):
    if SON_ACTIF and nom in SONS:
        try:
            SONS[nom].play()
        except Exception:
            pass


# ---------------------------------------------------------------- Les images du jeu
# Toutes les images sont dans le dossier images_jeu, à côté de ce fichier, déjà à leur taille finale.
DOSSIER_IMAGES = os.path.join(DOSSIER, "images_jeu")
IMAGES = {}
PRINCE = "perso_prince_dos_armure"
MAGES = {"épée": "perso_mage_epee", "bouclier": "perso_mage_bouclier",
         "armure": "perso_mage_armure", "potion": "perso_mage_potion"}
ARCHERS = {"lutin": "perso_archer_jeune", "ancien": "perso_archer_vieux"}
ENNEMIS_IMAGES = {"dragon": "perso_dragon", "troll": "perso_troll", "squelette": "perso_spectre", "voleur": "perso_voleur"}
IMAGES_OBJETS = {"épée": "objet_epee", "bouclier": "objet_bouclier", "armure": "objet_armure", "potion": "objet_potion"}
_caches = {}


def charger_images():
    """Charge toutes les images du dossier images_jeu (une seule fois, au démarrage)."""
    if not os.path.isdir(DOSSIER_IMAGES):
        print("Dossier images_jeu introuvable : il doit être dans le même dossier que le jeu.")
        return
    for fichier in sorted(os.listdir(DOSSIER_IMAGES)):
        if fichier.endswith((".png", ".jpg")):
            img = pygame.image.load(os.path.join(DOSSIER_IMAGES, fichier))
            nom = fichier[:-4]
            IMAGES[nom] = img.convert() if nom.startswith("fond_") else img.convert_alpha()


def image(nom):
    """Une image du jeu. Si elle manque, un rectangle violet la remplace (le jeu ne plante pas)."""
    if nom not in IMAGES:
        s = pygame.Surface((L, H) if nom.startswith("fond_") else (120, 200), pygame.SRCALPHA)
        s.fill((40, 30, 50, 255) if nom.startswith("fond_") else (160, 60, 200, 200))
        IMAGES[nom] = s
    return IMAGES[nom]


def image_echelle(nom, echelle=1.0, souffle=0):
    """L'image à une autre taille (gardée en mémoire). souffle = 0, 1 ou 2 : un tout petit peu plus haute (respiration)."""
    echelle = round(echelle * 50) / 50  # on arrondit pour ne pas fabriquer une image différente à chaque fois
    cle = ("echelle", nom, echelle, souffle)
    if cle not in _caches:
        img = image(nom)
        if echelle == 1.0 and souffle == 0:
            _caches[cle] = img
        else:
            largeur = max(1, int(img.get_width() * echelle))
            hauteur = max(1, int(img.get_height() * echelle * (1 + 0.012 * souffle)))
            _caches[cle] = pygame.transform.smoothscale(img, (largeur, hauteur))
    return _caches[cle]


def ombre_sol(largeur, haut):
    """L'ombre ovale sous un personnage (gardée en mémoire pour chaque taille)."""
    cle = ("ombre", largeur, haut)
    if cle not in _caches:
        s = pygame.Surface((largeur * 2, haut), pygame.SRCALPHA)
        pygame.draw.ellipse(s, (0, 0, 0, 120), (0, 0, largeur * 2, haut))
        _caches[cle] = s
    return _caches[cle]


def poser(ecran, nom, x, pied, echelle=1.0, flash=0, alpha=255, angle=0.0, ombre=True, souffle=0, miroir=False):
    """Pose un personnage : ses pieds en (x, pied). flash : il devient blanc (touché) ; alpha < 255 : il s'efface ;
    angle : il se penche (coup d'épée, attaque) ; miroir : il regarde de l'autre côté."""
    img = image_echelle(nom, echelle, souffle)
    if miroir:
        img = _caches.setdefault(("miroir", nom, round(echelle * 50) / 50, souffle), pygame.transform.flip(img, True, False))
    if angle:
        img = pygame.transform.rotozoom(img, angle, 1.0)
    if flash > 0 or alpha < 255:
        img = img.copy()
        if flash > 0:
            f = min(255, int(flash))
            img.fill((f, f, f, 0), special_flags=pygame.BLEND_RGB_ADD)
        if alpha < 255:
            img.set_alpha(max(0, int(alpha)))
    if ombre and alpha > 60:
        lo = max(4, int(img.get_width() * 0.42))
        ecran.blit(ombre_sol(lo, max(6, int(lo * 0.22))), (int(x) - lo, int(pied) - int(lo * 0.13)))
    ecran.blit(img, img.get_rect(midbottom=(int(x), int(pied))))
    return img.get_rect(midbottom=(int(x), int(pied)))


def respiration(t, vitesse=2.2, decalage=0.0):
    """0, 1 ou 2 : la respiration d'un personnage (il grandit très légèrement puis revient)."""
    return int(round(1 + math.sin(t * vitesse + decalage)))


def objet_surface(nom):
    """L'image d'un objet (épée, bouclier, armure, potion)."""
    return image(IMAGES_OBJETS[nom])


def poser_objet(ecran, nom, x, y, taille, angle=0):
    """Pose un objet centré en (x, y), dans un carré de « taille » pixels."""
    img = objet_surface(nom)
    k = taille / max(img.get_width(), img.get_height())
    img = image_echelle(IMAGES_OBJETS[nom], k)
    if angle:
        img = pygame.transform.rotozoom(img, angle, 1.0)
    ecran.blit(img, img.get_rect(center=(int(x), int(y))))


def coeur(s, x, y, r, couleur):
    pygame.draw.circle(s, couleur, (x - r // 2, y), r // 2 + 1)
    pygame.draw.circle(s, couleur, (x + r // 2, y), r // 2 + 1)
    pygame.draw.polygon(s, couleur, [(x - r, y + 2), (x + r, y + 2), (x, y + r + 4)])


# ---- Petits outils de dessin (pour les décors encore dessinés par le code : source de vie, épreuves)
def teinte(c, k):
    """k > 1 : plus clair ; k < 1 : plus sombre."""
    if k >= 1:
        return tuple(min(255, int(v + (255 - v) * (k - 1))) for v in c[:3])
    return tuple(max(0, int(v * k)) for v in c[:3])


def R(x, y, w, h):
    """Un rectangle avec des nombres entiers (pygame les préfère)."""
    return pygame.Rect(int(x), int(y), max(1, int(w)), max(1, int(h)))


def ovale(s, c, rect, reflet=True):
    r = pygame.Rect(rect)
    pygame.draw.ellipse(s, teinte(c, 0.6), r)
    pygame.draw.ellipse(s, c, R(r.x + r.w * 0.02, r.y + r.h * 0.02, r.w * 0.86, r.h * 0.84))
    if reflet and r.w > 10:
        pygame.draw.ellipse(s, teinte(c, 1.4), R(r.x + r.w * 0.18, r.y + r.h * 0.14, r.w * 0.24, r.h * 0.2))


def plaque(s, c, pts, reflet=True):
    """Une grande forme : bord sombre, centre éclairé décalé vers le haut à gauche."""
    pygame.draw.polygon(s, teinte(c, 0.62), pts)
    cx = sum(p[0] for p in pts) / len(pts)
    cy = sum(p[1] for p in pts) / len(pts)
    pygame.draw.polygon(s, c, [(cx + (px - cx) * 0.86 - 2, cy + (py - cy) * 0.9 - 2) for px, py in pts])
    if reflet:
        pygame.draw.polygon(s, teinte(c, 1.18), [(cx + (px - cx) * 0.45 - 6, cy + (py - cy) * 0.55 - 8) for px, py in pts])


def lisse(t0, t1, p):
    """0 avant t0, 1 après t1, et une transition douce entre les deux."""
    u = max(0.0, min(1.0, (p - t0) / (t1 - t0)))
    return u * u * (3 - 2 * u)


def fontaine(s, x, y, t, active=True):
    """Source de vie : une vasque de pierre, de l'eau qui ondule et un coeur lumineux qui flotte."""
    pierre = (112, 106, 124)
    ovale(s, pierre, R(x - 78, y - 36, 156, 42))
    plaque(s, pierre, [(x - 18, y - 100), (x + 18, y - 100), (x + 24, y - 26), (x - 24, y - 26)])
    ovale(s, teinte(pierre, 1.15), R(x - 60, y - 124, 120, 38))
    pygame.draw.ellipse(s, (70, 150, 210) if active else (82, 86, 96), R(x - 48, y - 118, 96, 22))
    if active:
        for i in range(3):  # ronds dans l'eau
            q = (t * 0.7 + i / 3) % 1
            pygame.draw.ellipse(s, (170, 225, 255), R(x - 10 - 34 * q, y - 110 - 6 * q, 20 + 68 * q, 6 + 12 * q), 1)
        flotte = math.sin(t * 3) * 6
        battement = 1 + 0.12 * max(0.0, math.sin(t * 6))
        coeur(s, x, int(y - 168 + flotte), int(28 * battement), (255, 70, 115))
        coeur(s, x - 4, int(y - 172 + flotte), int(12 * battement), (255, 150, 185))
        for i in range(6):
            a = t * 2 + i * 1.05
            pygame.draw.circle(s, (255, 230, 240), (int(x + math.cos(a) * 52), int(y - 150 + math.sin(a * 1.0) * 30)), 2)


def decor_epreuve(s, x, y, salle, t):
    """Le décor d'une salle d'épreuve : la porte à énigme, les pierres à runes ou la fosse et son coffre."""
    sorte, fait = salle["jeu"], salle.get("fait")
    if sorte == "enigme":  # une porte de pierre en arc, avec un gros « ? » qui brille
        pierre, bord = (98, 90, 104), (60, 54, 66)
        pygame.draw.ellipse(s, pierre, (x - 62, y - 196, 124, 124))
        pygame.draw.rect(s, pierre, (x - 62, y - 134, 124, 134))
        pygame.draw.ellipse(s, bord, (x - 62, y - 196, 124, 124), 4)
        pygame.draw.line(s, bord, (x - 62, y - 134), (x - 62, y), 4)
        pygame.draw.line(s, bord, (x + 60, y - 134), (x + 60, y), 4)
        if fait and salle.get("reussi"):  # porte ouverte : on voit le noir derrière
            pygame.draw.ellipse(s, (14, 10, 18), (x - 44, y - 176, 88, 88))
            pygame.draw.rect(s, (14, 10, 18), (x - 44, y - 132, 88, 132))
        else:
            for k in range(4):  # des inscriptions gravées
                pygame.draw.line(s, bord, (x - 40, y - 40 + k * 10), (x + 40 - (k % 2) * 18, y - 40 + k * 10), 2)
            if not fait:
                s.blit(lueur(60, (70, 50, 120)), (x - 60, y - 168), special_flags=pygame.BLEND_RGB_ADD)
            couleur = (120, 110, 130) if fait else (200, 180, 255)
            signe = petite_police(70).render("?", True, couleur)
            s.blit(signe, signe.get_rect(center=(x, y - 112 + int(math.sin(t * 2) * 3 * (not fait)))))
    elif sorte == "runes":  # quatre pierres levées, chacune avec sa rune de couleur
        for i in range(4):
            px, py = x - 78 + i * 52, y - 6 + abs(i - 1.5) * 6
            pygame.draw.rect(s, (88, 82, 96), (px - 18, py - 74, 36, 74), border_radius=10)
            pygame.draw.rect(s, (55, 50, 62), (px - 18, py - 74, 36, 74), 3, border_radius=10)
            c = COULEURS_RUNES[i]
            if fait:
                c = teinte(c, 0.35)
            elif math.sin(t * 2.5 + i * 1.6) > 0.6:  # elles scintillent l'une après l'autre
                s.blit(lueur(30, tuple(v // 3 for v in c)), (px - 30, py - 68), special_flags=pygame.BLEND_RGB_ADD)
            for a, b in GLYPHES[i]:
                pygame.draw.line(s, c, (px + a[0] * 0.5, py - 38 + a[1] * 0.5), (px + b[0] * 0.5, py - 38 + b[1] * 0.5), 3)
    else:  # la fosse, et le coffre de l'autre côté
        pygame.draw.ellipse(s, (40, 34, 44), (x - 104, y - 34, 208, 58))
        pygame.draw.ellipse(s, (6, 4, 8), (x - 96, y - 30, 192, 48))
        cx, cy = x + 10, y - 78  # le coffre, plus loin (donc plus haut et plus petit)
        pygame.draw.rect(s, (110, 64, 28), (cx - 30, cy - 22, 60, 34), border_radius=4)
        pygame.draw.rect(s, (70, 40, 16), (cx - 30, cy - 22, 60, 34), 2, border_radius=4)
        if fait and salle.get("reussi"):  # coffre ouvert et vide
            pygame.draw.polygon(s, (130, 76, 34), [(cx - 30, cy - 22), (cx + 30, cy - 22), (cx + 26, cy - 48), (cx - 26, cy - 48)])
            pygame.draw.rect(s, (20, 12, 8), (cx - 26, cy - 22, 52, 8))
        else:
            pygame.draw.rect(s, (130, 76, 34), (cx - 32, cy - 34, 64, 14), border_radius=6)
            pygame.draw.rect(s, (230, 190, 60), (cx - 4, cy - 26, 8, 12))
            if not fait and math.sin(t * 3) > 0.7:  # un petit éclat doré
                etoile = (cx + 22, cy - 34)
                pygame.draw.line(s, (255, 240, 170), (etoile[0] - 7, etoile[1]), (etoile[0] + 7, etoile[1]), 2)
                pygame.draw.line(s, (255, 240, 170), (etoile[0], etoile[1] - 7), (etoile[0], etoile[1] + 7), 2)


def dessin_agrandi(ecran, fonction, taille, args, x, pied, echelle):
    """Dessine un décor « fait par le code » sur une petite feuille, puis l'agrandit pour la grande fenêtre."""
    cle = ("feuille", taille)
    if cle not in _caches:
        _caches[cle] = pygame.Surface(taille, pygame.SRCALPHA)
    feuille = _caches[cle]
    feuille.fill((0, 0, 0, 0))
    fonction(feuille, taille[0] // 2, taille[1] - 20, *args)
    grand = pygame.transform.smoothscale(feuille, (int(taille[0] * echelle), int(taille[1] * echelle)))
    ecran.blit(grand, grand.get_rect(midbottom=(int(x), int(pied + 20 * echelle))))


# --- Effets de lumière (fabriqués une seule fois, puis gardés en mémoire)
def lueur(rayon, couleur):
    """Halo de lumière, à ajouter sur l'image (BLEND_RGB_ADD)."""
    cle = ("lueur", rayon, couleur)
    if cle not in _caches:
        s = pygame.Surface((rayon * 2, rayon * 2))
        for r in range(rayon, 0, -3):
            f = (1 - r / rayon) ** 2
            pygame.draw.circle(s, tuple(int(c * f) for c in couleur), (rayon, rayon), r)
        _caches[cle] = s
    return _caches[cle]


def vignette():
    """Bords de l'écran assombris, comme dans une vraie grotte."""
    if "vignette" not in _caches:
        v = pygame.Surface((L, H), pygame.SRCALPHA)
        for i in range(90):
            pygame.draw.rect(v, (0, 0, 0, int(150 * (1 - i / 90) ** 2)), (i, i, L - 2 * i, H - 2 * i), 1)
        _caches["vignette"] = v
    return _caches["vignette"]


def fumee(s, x, y, t):
    """Nuage violet de la potion de téléportation."""
    if "nuage" not in _caches:  # la feuille transparente est créée une seule fois
        _caches["nuage"] = pygame.Surface((L, H), pygame.SRCALPHA)
    nuage = _caches["nuage"]
    nuage.fill((0, 0, 0, 0))
    for i in range(9):
        a = t * 2 + i * 0.7
        pygame.draw.circle(nuage, (150, 60, 200, 150),
                           (int(x + math.cos(a) * 85), int(y - 130 + math.sin(a * 1.3) * 110)), 56 + i * 4)
    s.blit(nuage, (0, 0))


def etincelles(ecran, x, y, p, couleur=(255, 235, 120), n=8, r1=22, r2=72):
    for i in range(n):
        a = i * 2 * math.pi / n + p * 3
        pygame.draw.line(ecran, couleur, (x + math.cos(a) * r1, y + math.sin(a) * r1),
                         (x + math.cos(a) * r2, y + math.sin(a) * r2), 4)


def jet_de_feu(ecran, depart, arrivee, p, t, pare):
    """Le souffle du dragon : des boules de feu qui filent de sa gueule jusqu'au chevalier.
    S'il pare avec son bouclier, les flammes s'écrasent dessus et s'étalent vers le haut."""
    avance = lisse(0.25, 0.5, p)        # la tête du jet avance...
    fin = lisse(0.7, 0.95, p)            # ...puis le jet s'éteint en partant de la gueule
    if avance <= 0 or fin >= 1:
        return
    (x0, y0), (x1, y1) = depart, arrivee
    ecran.blit(lueur(160, (140, 60, 0)), (int(x1) - 160, int(y1) - 160), special_flags=pygame.BLEND_RGB_ADD)
    for i in range(34):
        u = i / 33                       # 0 : à la gueule, 1 : sur le chevalier
        if u > avance or u < fin:
            continue
        ondule = math.sin(t * 25 + i * 1.7) * (5 + 18 * u)
        x = x0 + (x1 - x0) * u
        y = y0 + (y1 - y0) * u + ondule
        r = int(8 + 28 * u)
        pygame.draw.circle(ecran, (230, int(70 + 60 * (1 - u)), 20), (int(x), int(y)), r)
        pygame.draw.circle(ecran, (255, int(190 + 50 * (1 - u)), int(60 + 120 * (1 - u))),
                           (int(x - r * 0.2), int(y - r * 0.2)), max(2, int(r * 0.55)))
    if avance >= 1:  # là où les flammes frappent
        for k in range(7):
            a = -math.pi / 2 + (k - 3) * 0.4 + math.sin(t * 12 + k) * 0.15
            longueur = (55 if pare else 36) + 16 * math.sin(t * 18 + k * 2)
            bout = (x1 + math.cos(a) * longueur, y1 + math.sin(a) * longueur)
            pygame.draw.line(ecran, (255, 150, 30), (int(x1), int(y1)), (int(bout[0]), int(bout[1])), 8)
            pygame.draw.circle(ecran, (255, 220, 120), (int(bout[0]), int(bout[1])), 5)


# ---------------------------------------------------------------- La scène
# Où se tiennent les personnages (fenêtre 1280 x 720 ; la boîte de texte commence à HAUT_SCENE)
# Le chevalier se tient entre le tunnel de gauche et celui du milieu, les autres entre celui du milieu et
# celui de droite : comme ça, personne ne cache une entrée.
KX_CENTRE, KX_COMBAT, KY = 420, 420, 556   # le chevalier (même place en exploration et en combat)
EX, EY = 835, 488                          # l'ennemi, en face de lui (un peu plus loin, donc plus haut)
OCC_X, OCC_Y = 835, 500                    # le mage, l'archer, la source... dans une salle tranquille
OBJET_X, OBJET_Y = OCC_X - 75, OCC_Y - 300  # l'objet que le mage fait flotter au-dessus de sa main
SOL_TUNNEL = 425                           # le sol à l'entrée des tunnels du fond
TORCHES = [(65, 258), (452, 258), (823, 258), (1217, 258)]  # les flammes des torches de fond_salle
# Pendant ces animations, on voit encore l'ennemi même s'il vient d'être vaincu
ANIMS_ENNEMI_VISIBLE = ("arrivee", "vol", "degats", "approche", "coup", "touche", "mort_ennemi", "riposte", "fuit")


def echelle_a(y):
    """Plus le chevalier est loin (y petit, vers les tunnels), plus il est petit."""
    return 0.42 + 0.58 * (y - SOL_TUNNEL) / (KY - SOL_TUNNEL)


def genre_ennemi(scene):
    return scene.get("boss", scene["type"])


def ennemi_visible(scene, genre_anim):
    return scene["type"] in ENNEMIS and (not scene.get("vaincu") or genre_anim in ANIMS_ENNEMI_VISIBLE)


def dessiner_fond(ecran, nom, t):
    """L'image de fond ; dans la salle, les torches vacillent un peu."""
    ecran.blit(image(nom), (0, 0))
    if nom == "fond_salle":
        for i, (tx, ty) in enumerate(TORCHES):
            k = round(0.45 + 0.25 * math.sin(t * 9 + i * 2.1) + 0.1 * math.sin(t * 23 + i), 1)
            ecran.blit(lueur(90, (int(110 * k), int(55 * k), int(12 * k))), (tx - 90, ty - 90),
                       special_flags=pygame.BLEND_RGB_ADD)


def marqueur(ecran, x, y, dort, t):
    """Au-dessus d'un ennemi : des Z s'il dort, un point d'exclamation rouge s'il t'a vu."""
    if dort:
        for k in range(3):
            taille = 11 + 7 * k
            zx, zy = x + k * 22, y - k * 25 - int((t * 18) % 14)
            pygame.draw.lines(ecran, (210, 225, 255), False,
                              [(zx, zy), (zx + taille, zy), (zx, zy + taille), (zx + taille, zy + taille)], 4)
    else:
        r = 6 + int(abs(math.sin(t * 8)) * 3)
        pygame.draw.rect(ecran, (255, 60, 50), (x - 6, y - 48, 12, 32), border_radius=4)
        pygame.draw.circle(ecran, (255, 60, 50), (x, y - 2), r)


def dessiner_salle(ecran, scene, inv, t, anim, p):
    """La salle vue de dos : le chevalier au premier plan, l'occupant ou l'ennemi en face, trois entrées au fond."""
    typ = scene["type"]
    genre = anim["type"] if anim else None
    dort = scene.get("dort")
    visible = ennemi_visible(scene, genre)
    dessiner_fond(ecran, "fond_antre" if typ == "dragon" else "fond_salle", t)
    base_x = KX_COMBAT if visible else KX_CENTRE

    # --- où est le chevalier, et que fait-il ?
    kx, ky, angle, parade, marche = base_x, KY, 0.0, 0.0, False
    if genre == "marche" and anim["dir"] == "bas":  # il recule vers nous
        ky, marche = KY + 170 * p * p, True
    elif genre == "marche":  # il marche vers l'entrée choisie, qui s'approche et le rapetisse
        kx, ky, marche = base_x + (TUNNELS[anim["dir"]] - base_x) * p, KY - (KY - SOL_TUNNEL) * p, True
    elif genre == "arrivee":  # il entre dans la salle par le bas de l'écran
        ky, marche = KY + 170 * (1 - p) ** 2, True
    elif genre == "approche":  # il s'avance vers l'ennemi (sur la pointe des pieds pour le surprendre)
        kx, ky, marche = base_x + 90 * p, KY - 30 * p, True
    elif genre == "coup":  # il bondit vers l'ennemi et frappe, puis revient
        saut = math.sin(math.pi * p)
        kx, ky, angle = base_x + 250 * saut, KY - 70 * saut, -14 * saut
    elif genre == "degats":  # il tremble sous le choc
        kx = base_x + math.sin(p * 40) * 12 * (1 - p)
    elif genre == "riposte" and anim.get("pare"):  # il lève son bouclier
        parade = lisse(0, 0.3, p) * (1 - lisse(0.85, 1, p))
    elif genre == "retour":  # il revient au centre de la salle
        x0 = anim.get("x0", KX_COMBAT)
        kx, marche = x0 + (base_x - x0) * p, True
    elif genre == "recul":  # il fuit vers nous
        ky, marche = KY + 170 * p * p, True
    elif genre == "saut":  # la fosse : un bond par-dessus... ou une chute dedans
        if anim.get("reussi"):
            kx, ky = base_x + 70 * math.sin(math.pi * p), KY - 120 * math.sin(math.pi * p)
        else:
            q = lisse(0, 0.5, p)
            kx, ky = base_x + 170 * q, KY - 80 * q - 55 * math.sin(math.pi * q) + 30 * lisse(0.5, 1, p)
    if marche:  # il se balance un peu en marchant
        ky -= abs(math.sin(t * 11)) * 7

    # --- l'occupant de la salle
    bouche = None  # où est la gueule du dragon (pour son souffle de feu)
    if typ == "mage":
        poser(ecran, MAGES[scene["objet"]], OCC_X, OCC_Y, souffle=respiration(t, 2.0))
        if genre != "don":  # l'objet flotte au-dessus de sa main
            poser_objet(ecran, scene["objet"], OBJET_X, OBJET_Y + int(math.sin(t * 3) * 8), 90)
    elif typ == "ami":
        poser(ecran, ARCHERS[scene["perso"]], OCC_X, OCC_Y, souffle=respiration(t, 2.4))
    elif typ == "coeur":
        dessin_agrandi(ecran, fontaine, (300, 260), (t, scene.get("source", True)), OCC_X, OCC_Y, 1.45)
    elif typ == "epreuve":
        dessin_agrandi(ecran, decor_epreuve, (300, 260), (scene, t), OCC_X - 20, OCC_Y + 10, 1.6)
    elif typ in ENNEMIS and visible:
        sorte = genre_ennemi(scene)
        nom = ENNEMIS_IMAGES[sorte]
        if sorte == "dragon" and dort and not scene.get("combat"):
            nom = "perso_dragon_dort"
        ex, ey, ech, flash, alpha, penche = EX, EY, 1.0, 0, 255, 0.0
        if sorte == "squelette":  # le spectre flotte
            ey -= 14 + math.sin(t * 2.5) * 10
        if genre == "riposte":  # il attaque : il fonce vers toi puis recule
            elan = math.sin(math.pi * min(1, p * 1.2))
            ex, ey, ech, penche = ex - 170 * elan, ey + 45 * elan, 1 + 0.18 * elan, 8 * elan
        elif genre == "touche":  # il est touché : il clignote en blanc et recule
            ex, flash = ex + 30 * math.sin(math.pi * p) + math.sin(p * 50) * 8 * (1 - p), 220 * (1 - p)
        elif genre == "mort_ennemi":  # il s'effondre et disparaît
            ey, alpha, flash = ey + 40 * p, 255 * (1 - p), 140 * (1 - p)
        elif genre == "fuit" or (genre == "vol" and p > 0.6):  # le voleur s'enfuit
            q = p if genre == "fuit" else (p - 0.6) / 0.4
            ex, ey = ex + 520 * q, ey - 40 * q
        elif genre == "coup" and p > 0.5:  # l'impact le secoue
            ex += math.sin(p * 60) * 9
        souffle = respiration(t, 1.2 if dort else 2.2)
        cadre = poser(ecran, nom, ex, ey, ech, flash, alpha, penche, souffle=souffle, miroir=(sorte == "dragon"))
        if genre == "mort_ennemi":  # petits nuages de fumée
            for i in range(7):
                a = i * 0.9
                r = 14 + 42 * p
                pygame.draw.circle(ecran, (170, 165, 180), (int(EX + math.cos(a) * 85 * p),
                                   int(EY - 120 - math.sin(a) * 70 * p - 55 * p)), int(r * (1 - p * 0.5)), 3)
        if genre == "riposte" and sorte == "dragon":
            bouche = (cadre.x + cadre.width * 0.36, cadre.y + cadre.height * 0.17)
        if dort is not None and genre in (None, "arrivee") and not scene.get("combat"):
            marqueur(ecran, cadre.right - 30, cadre.y + 30, dort, t)  # Zzz ou !
    elif typ == "fuite":
        fumee(ecran, KX_CENTRE, KY, t)

    # --- le chevalier
    if scene.get("mort") and genre in (None, "chute"):  # battu : il tombe puis reste allongé
        q = 1 if genre is None else min(1, p)
        couche = pygame.transform.rotozoom(image(PRINCE), 90 * q, 1.0)
        couche.fill((int(70 * q), int(70 * q), int(70 * q), 0), special_flags=pygame.BLEND_RGB_SUB)
        ecran.blit(couche, couche.get_rect(midbottom=(base_x - int(40 * q), KY + int(10 * q))))
    elif not (genre == "teleport" and p > 0.5):  # pendant la potion, il disparaît dans le nuage
        disparait = 255
        if genre == "saut" and not anim.get("reussi"):  # il tombe dans le noir de la fosse
            disparait = 255 * (1 - lisse(0.5, 0.9, p))
        if disparait > 0:
            poser(ecran, PRINCE, kx, ky, echelle_a(ky), alpha=disparait, angle=angle, souffle=respiration(t, 2.2, 1.0))
        if parade > 0 and "bouclier" in inv:  # le bouclier se lève devant lui
            poser_objet(ecran, "bouclier", kx + 30, ky - 200 - 30 * parade, int(150 * (0.6 + 0.4 * parade)))
    if genre == "teleport":  # le nuage violet de la potion grossit autour de lui
        fumee(ecran, base_x, KY - int(40 * p), t * (1 + 2 * p))

    # --- les effets, par-dessus tout le monde
    if bouche:  # le souffle du dragon
        pare = anim.get("pare") and "bouclier" in inv
        jet_de_feu(ecran, bouche, (kx + 30 if pare else kx + 10, KY - 210), p, t, pare)
    if genre == "coup" and 0.42 < p < 0.62:  # la traînée blanche de l'épée, puis les étincelles de l'impact
        pygame.draw.arc(ecran, (255, 255, 255), (EX - 230, EY - 300, 300, 260), 1.0, 2.9, 9)
        etincelles(ecran, EX - 20, EY - 170, p)
    if genre == "riposte" and 0.45 < p < 0.75:
        if anim.get("pare") and "bouclier" in inv:  # paré ! étincelles bleues sur le bouclier
            etincelles(ecran, base_x + 30, KY - 220, p, (150, 210, 255), 10, 26, 84)
        else:
            etincelles(ecran, base_x + 10, KY - 190, p, (255, 90, 70), 6, 18, 56)


def dessiner_victoire(ecran, t, anim, p):
    """La victoire : dans l'antre, la princesse accourt vers le prince."""
    dessiner_fond(ecran, "fond_antre", t)
    genre = anim["type"] if anim else None
    px, q = 840, 1.0
    if genre == "bise":
        px += int(420 * (1 - lisse(0, 0.6, p)))    # la princesse accourt...
        q = max(0.0, (p - 0.6) / 0.4)               # ...puis les coeurs jaillissent
    poser(ecran, "perso_princesse", px, 520, souffle=respiration(t, 2.4))
    hop = int(math.sin(q * math.pi) * 22) if genre == "bise" else 0  # le prince saute de joie
    poser(ecran, PRINCE, 520, KY - hop, souffle=respiration(t, 2.2, 1.0))
    if genre == "bise" and q > 0:
        coeur(ecran, 680, 250 - int(40 * q), int(16 + 36 * q), (255, 70, 120))
        for i in range(6):
            a = i * 1.05
            coeur(ecran, int(680 + math.cos(a) * 110 * q), int(270 + math.sin(a) * 80 * q), 11, (255, 130, 170))
    elif genre != "bise":
        for i in range(7):
            coeur(ecran, int(680 + 70 * math.sin(t * 1.5 + i * 2)), int(400 - ((t * 50 + i * 55) % 260)), 15, (240, 60, 100))


def dessiner_scene(ecran, scene, inv, t, anim=None, p=0):
    genre = anim["type"] if anim else None
    if genre == "bise" or scene["type"] == "victoire":
        dessiner_victoire(ecran, t, anim, p)
    else:
        dessiner_salle(ecran, scene, inv, t, anim, p)
    for i in range(40):  # poussière et braises qui flottent dans l'air
        px = (i * 131 + t * (6 + i % 5) * 3) % L
        py = (i * 71 - t * (10 + i % 6)) % (HAUT_SCENE - 60)
        lum = 120 + int(80 * math.sin(t * 2 + i))
        pygame.draw.circle(ecran, (lum, lum - 10, lum - 30), (int(px), int(py)), 1 + (i % 3 == 0))
    ecran.blit(vignette(), (0, 0))

def petite_police(taille=14):
    cle = ("police", taille)
    if cle not in _caches:
        _caches[cle] = pygame.font.SysFont("georgia,dejavusans,arial", taille)
    return _caches[cle]


def police_grasse(taille):
    cle = ("police_grasse", taille)
    if cle not in _caches:
        _caches[cle] = pygame.font.SysFont("georgia,dejavusans,arial", taille, bold=True)
    return _caches[cle]


def texte_ombre(ecran, police, texte, couleur, centre=None, topleft=None, ombre=(20, 12, 4), decalage=3):
    """Un texte avec une ombre portée : bien lisible sur une image de fond."""
    img = police.render(texte, True, couleur)
    r = img.get_rect(center=centre) if centre else img.get_rect(topleft=topleft)
    ecran.blit(police.render(texte, True, ombre), r.move(decalage, decalage))
    ecran.blit(img, r)
    return r


def voile(ecran, rect, alpha, couleur=(0, 0, 0)):
    """Un rectangle sombre et transparent, pour rendre un texte lisible sur une image."""
    cle = ("voile", rect[2], rect[3], alpha, couleur)
    if cle not in _caches:
        s = pygame.Surface((rect[2], rect[3]), pygame.SRCALPHA)
        s.fill((*couleur, alpha))
        _caches[cle] = s
    ecran.blit(_caches[cle], (rect[0], rect[1]))


def dessiner_sorties(ecran, police, t):
    """Tes choix de sortie : une flèche qui pulse dans chaque entrée de la salle. On peut cliquer dessus."""
    souris = pygame.mouse.get_pos()
    forme = [(-30, -8), (3, -8), (3, -22), (30, 0), (3, 22), (3, 8), (-30, 8)]  # flèche vers la droite
    touches = {"gauche": pygame.K_g, "haut": pygame.K_h, "droite": pygame.K_d, "bas": pygame.K_b}
    for direction, lettre in (("gauche", "g"), ("haut", "h"), ("droite", "d")):
        cx = TUNNELS[direction]
        cible = pygame.Rect(cx - 95, 200, 190, 230)  # toute l'entrée du tunnel est cliquable
        survol = cible.collidepoint(souris)
        zone(cible, touches[direction])
        pulse = 1 + (0.25 if survol else 0.12) * math.sin(t * 5) + (0.15 if survol else 0)
        pts = [(cx + y * pulse, 340 - x * pulse) for x, y in forme]  # tournée vers le haut : on entre dans le tunnel
        if survol:  # halo sous la flèche quand la souris est dessus
            ecran.blit(lueur(80, (120, 90, 20)), (cx - 80, 340 - 80), special_flags=pygame.BLEND_RGB_ADD)
        pygame.draw.polygon(ecran, (255, 235, 140) if survol else (255, 215, 90), pts)
        pygame.draw.polygon(ecran, (150, 110, 30), pts, 3)
        texte_ombre(ecran, police, f"{direction} ({lettre})", (255, 255, 255) if survol else (255, 235, 170),
                    centre=(cx, 222), decalage=2)
    # 4e choix, plus discret : reculer vers la salle d'en dessous (petite flèche vers le bas, en bas à droite)
    cible = pygame.Rect(L - 210, 440, 190, 110)
    survol = cible.collidepoint(souris)
    zone(cible, touches["bas"])
    k = 0.9 if survol else 0.75
    pts = [(L - 115 + y * k, 510 + x * k) for x, y in forme]
    pygame.draw.polygon(ecran, (255, 235, 140) if survol else (200, 180, 120), pts)
    pygame.draw.polygon(ecran, (110, 90, 40), pts, 3)
    texte_ombre(ecran, police, "reculer (b)", (255, 255, 255) if survol else (220, 205, 160),
                centre=(L - 115, 462), decalage=2)


# --- La carte de la grotte (touche C)
COULEURS_CARTE = {"enigme": (150, 130, 230), "runes": (90, 190, 200), "fosse": (210, 165, 70), "mage": (150, 100, 210),
                  "vide": (110, 110, 125), "ami": (90, 190, 110), "voleur": (200, 70, 80), "squelette": (120, 150, 255),
                  "troll": (120, 170, 100), "dragon": (230, 80, 50), "coeur": (240, 100, 150)}
NOMS_CARTE = {"enigme": "Énigme", "runes": "Runes", "fosse": "Fosse", "mage": "Mage", "vide": "Vide", "ami": "Ami",
              "voleur": "Voleur", "squelette": "Spectre", "troll": "Troll", "dragon": "Dragon", "coeur": "Source"}
LETTRES = {"gauche": "g", "haut": "h", "droite": "d", "bas": "b"}
CASE_L, CASE_H, PAS_X, PAS_Y = 150, 92, 180, 112  # taille d'une salle sur la carte, et écart entre deux salles
CARTE_X0 = 70 + (1140 - (GRILLE_L * PAS_X - (PAS_X - CASE_L))) // 2
CARTE_Y0 = 74


def reduire(brut, hauteur, largeur_max):
    """Découpe le dessin au plus juste (sans le vide autour) puis le réduit pour tenir dans la case."""
    r = brut.get_bounding_rect()
    if r.width == 0 or r.height == 0:
        return pygame.Surface((1, 1), pygame.SRCALPHA)
    morceau = brut.subsurface(r).copy()
    e = min(hauteur / r.height, largeur_max / r.width)
    return pygame.transform.smoothscale(morceau, (max(1, int(r.width * e)), max(1, int(r.height * e))))


def icone_vide(hauteur):
    """Petite toile d'araignée pour les salles vides."""
    s = pygame.Surface((hauteur, hauteur), pygame.SRCALPHA)
    angles = [math.radians(a) for a in range(0, 360, 45)]
    c = hauteur // 2
    for a in angles:
        pygame.draw.line(s, (170, 170, 190), (c, c), (c + c * math.cos(a), c + c * math.sin(a)), 1)
    for r in (c // 3, 2 * c // 3, c - 1):
        pygame.draw.polygon(s, (170, 170, 190), [(c + r * math.cos(a), c + r * math.sin(a)) for a in angles], 1)
    pygame.draw.circle(s, (20, 20, 25), (c + c // 3, c - c // 4), 4)
    return s


def nom_icone(salle):
    """Quelle image montrer sur la carte pour cette salle (None = un dessin fait par le code)."""
    genre = salle.get("ancien") or salle.get("boss", salle["type"])
    if salle["type"] == "mage":
        return MAGES[salle["objet"]]
    if salle["type"] == "ami":
        return ARCHERS[salle.get("perso", "lutin")]
    return ENNEMIS_IMAGES.get(genre)


def icone(salle, hauteur=60, largeur_max=90):
    """Le personnage ou le décor de la salle, en miniature. Fabriqué une seule fois."""
    genre = salle["jeu"] if salle["type"] == "epreuve" else salle.get("ancien") or salle.get("boss", salle["type"])
    cle = ("icone", genre, salle.get("objet"), salle.get("perso"), salle.get("source", True), hauteur,
           salle.get("fait"), salle.get("reussi"))
    if cle in _caches:
        return _caches[cle]
    nom = nom_icone(salle)
    if nom:
        img = reduire(image(nom), hauteur, largeur_max)
    elif genre == "vide":
        img = icone_vide(hauteur)
    else:  # la source de vie ou une épreuve : le décor dessiné par le code
        brut = pygame.Surface((300, 260), pygame.SRCALPHA)
        if genre in EPREUVES:
            decor_epreuve(brut, 150, 240, salle, 0.0)
        else:
            fontaine(brut, 150, 240, 0.0, salle.get("source", True))
        img = reduire(brut, hauteur, largeur_max)
    if salle.get("ancien") or salle.get("fait"):  # ennemi vaincu ou épreuve terminée : dessin grisé
        img = img.copy()
        img.fill((95, 95, 95), special_flags=pygame.BLEND_RGB_MULT)
    _caches[cle] = img
    return img


def case_carte(c):
    x, y = c
    return pygame.Rect(CARTE_X0 + x * PAS_X, CARTE_Y0 + y * PAS_Y, CASE_L, CASE_H)


def couloirs(a, b):
    """Les morceaux de couloir qui relient deux salles voisines sur la carte.
    Si le couloir fait le tour de la grotte (bord gauche <-> bord droit), on dessine un bout de chaque côté."""
    (ax, ay), (bx, by) = a, b
    ra, rb = case_carte(a), case_carte(b)
    gx, gy = PAS_X - CASE_L, PAS_Y - CASE_H  # largeur des espaces entre les salles
    if ay == by:  # couloir horizontal
        if (ax + 1) % GRILLE_L != bx:
            return couloirs(b, a)
        if bx == ax + 1:
            return [pygame.Rect(ra.right, ra.centery - 7, gx, 14)]
        return [pygame.Rect(ra.right, ra.centery - 7, 20, 14), pygame.Rect(rb.x - 20, rb.centery - 7, 20, 14)]
    if (ay + 1) % GRILLE_H != by:  # couloir vertical
        return couloirs(b, a)
    if by == ay + 1:
        return [pygame.Rect(ra.centerx - 7, ra.bottom, 14, gy)]
    return [pygame.Rect(ra.centerx - 7, ra.bottom, 14, 18), pygame.Rect(rb.centerx - 7, rb.y - 18, 14, 18)]


def bout_de_tunnel(ecran, morceau, case, couleur):
    """Un couloir qui sort par le bord de la carte : un petit bout avec une pointe vers l'extérieur."""
    pygame.draw.rect(ecran, couleur, morceau)
    cx, cy = morceau.center
    if morceau.width > morceau.height:  # sort à gauche ou à droite
        sens = -1 if morceau.right <= case.x + 1 else 1
        pointe = [(cx + sens * 16, cy), (cx + sens * 5, cy - 10), (cx + sens * 5, cy + 10)]
    else:  # sort en haut ou en bas
        sens = -1 if morceau.bottom <= case.y + 1 else 1
        pointe = [(cx, cy + sens * 15), (cx - 10, cy + sens * 5), (cx + 10, cy + sens * 5)]
    pygame.draw.polygon(ecran, couleur, pointe)


def dessiner_carte(ecran, police, jeu):
    """La carte de la grotte (touche C) : les salles visitées avec leur occupant, les couloirs qui les
    relient (dorés = déjà empruntés), et tes 4 sorties possibles depuis la salle où tu es."""
    t = pygame.time.get_ticks() / 1000
    petite, legende = petite_police(17), petite_police(18)
    vus, chemins, pos = jeu["vus"], jeu.get("chemins", set()), jeu["pos"]
    panneau = pygame.Rect(70, 18, 1140, 540)
    voile(ecran, (0, 0, L, HAUT_SCENE), 150, (5, 3, 8))  # tout le reste s'assombrit derrière la carte
    voile(ecran, panneau, 242, (15, 12, 22))
    pygame.draw.rect(ecran, (150, 130, 80), panneau, 3, border_radius=14)
    titre = police.render("CARTE DE LA GROTTE   (C pour fermer)", True, (240, 200, 60))
    ecran.blit(titre, (panneau.centerx - titre.get_width() // 2, panneau.y + 14))

    # 1. Les couloirs entre les salles (chaque salle a 4 voisines : la grotte fait le tour)
    for (x, y) in jeu["grotte"]:
        a = (x, y)
        for b in (((x + 1) % GRILLE_L, y), (x, (y + 1) % GRILLE_H)):
            if frozenset((a, b)) in chemins:
                couleur = (205, 165, 70)  # déjà emprunté
            elif a in vus or b in vus:
                couleur = (82, 74, 98)    # on sait qu'il existe
            else:
                couleur = (40, 36, 52)    # pas encore exploré
            morceaux = couloirs(a, b)
            if len(morceaux) == 1:
                pygame.draw.rect(ecran, couleur, morceaux[0])
            else:
                for morceau in morceaux:
                    case = case_carte(a) if morceau.colliderect(case_carte(a).inflate(4, 4)) else case_carte(b)
                    bout_de_tunnel(ecran, morceau, case, couleur)

    # 2. Les salles
    for c, salle in jeu["grotte"].items():
        case = case_carte(c)
        if c not in vus:
            pygame.draw.rect(ecran, (30, 27, 40), case, border_radius=10)
            pygame.draw.rect(ecran, (55, 50, 70), case, 1, border_radius=10)
            texte = police.render("?", True, (110, 100, 140))
            ecran.blit(texte, texte.get_rect(center=case.center))
            continue
        vaincu = salle.get("ancien")
        genre = salle["jeu"] if salle["type"] == "epreuve" else vaincu or salle.get("boss", salle["type"])
        terne = vaincu or salle.get("fait")
        cadre = tuple(c_ // 2 for c_ in COULEURS_CARTE[genre]) if terne else COULEURS_CARTE[genre]
        pygame.draw.rect(ecran, (48, 42, 60), case, border_radius=10)
        pygame.draw.rect(ecran, cadre, case, 2, border_radius=10)
        img = icone(salle)
        centre_x = case.x + 48 if c == pos else case.centerx  # on laisse de la place au petit chevalier
        ecran.blit(img, img.get_rect(midbottom=(centre_x, case.y + 68)))
        if salle["type"] == "mage":  # l'objet que donne ce mage
            poser_objet(ecran, salle["objet"], case.right - 18, case.y + 18, 28)
        nom = petite.render(NOMS_CARTE[genre], True, (150, 145, 160) if terne else (235, 230, 245))
        ecran.blit(nom, nom.get_rect(midbottom=(case.centerx, case.bottom - 2)))
        cx, cy = case.x + 15, case.y + 15
        if vaincu:  # une croix rouge : « vaincu ! »
            pygame.draw.line(ecran, (255, 70, 70), (cx - 7, cy - 7), (cx + 7, cy + 7), 4)
            pygame.draw.line(ecran, (255, 70, 70), (cx - 7, cy + 7), (cx + 7, cy - 7), 4)
        elif salle.get("fait"):  # épreuve terminée : coche verte (réussie) ou trait gris (ratée)
            if salle.get("reussi"):
                pygame.draw.lines(ecran, (90, 230, 120), False, [(cx - 8, cy), (cx - 2, cy + 7), (cx + 9, cy - 8)], 4)
            else:
                pygame.draw.line(ecran, (150, 145, 160), (cx - 8, cy), (cx + 8, cy), 4)

    # 3. Toi, et tes 4 sorties qui clignotent doucement
    case = case_carte(pos)
    pygame.draw.rect(ecran, (255, 215, 90), case, 4, border_radius=10)
    if "moi" not in _caches:  # toi, en miniature
        _caches["moi"] = reduire(image(PRINCE), 54, 50)
    moi = _caches["moi"]
    ecran.blit(moi, moi.get_rect(midbottom=(case.right - 28, case.y + 68)))
    lueur_ = 0.6 + 0.4 * math.sin(t * 5)
    jaune = (255, int(150 + 65 * lueur_), int(40 + 50 * lueur_))
    for direction, (dx, dy) in DEPLACEMENTS.items():
        dest = ((pos[0] + dx) % GRILLE_L, (pos[1] + dy) % GRILLE_H)
        morceaux = couloirs(pos, dest)
        morceau = next((m for m in morceaux if m.colliderect(case.inflate(4, 4))), morceaux[0])
        pygame.draw.rect(ecran, jaune, morceau.inflate(2, 2), 2)
        pygame.draw.circle(ecran, (40, 30, 10), morceau.center, 13)
        pygame.draw.circle(ecran, jaune, morceau.center, 13, 2)
        lettre = petite.render(LETTRES[direction], True, jaune)
        ecran.blit(lettre, lettre.get_rect(center=(morceau.centerx, morceau.centery - 1)))

    lignes = ("Le petit chevalier, c'est toi. Les lettres g, h, d, b sont tes sorties.",
              "Couloir doré : déjà pris. Une flèche au bord : le couloir fait le tour de la grotte.")
    for i, ligne in enumerate(lignes):
        texte = legende.render(ligne, True, (190, 185, 210))
        ecran.blit(texte, (panneau.centerx - texte.get_width() // 2, panneau.bottom - 50 + i * 23))


def centre_case(obj):
    """Le centre de la case de cet objet, dans l'inventaire en haut à gauche."""
    return (16 + OBJETS.index(obj) * 80 + 36, 52)


def dessiner_vol_objet(ecran, anim, p):
    """Ce qui voyage à l'écran : objet du mage vers l'inventaire (don), de l'inventaire vers le sac du voleur (vol),
    coeur vers la barre de vie (soin)."""
    genre = anim["type"]
    if genre == "soin":
        depart, arrivee, t1, t2, q = (OCC_X, OCC_Y - 250), (32 + anim["cible"] * 36, 122), 34, 12, p
    elif genre == "don":
        depart, arrivee, t1, t2, q = (OBJET_X, OBJET_Y), centre_case(anim["objet"]), 90, 60, p
    else:
        if p > 0.6:
            return
        depart, arrivee, t1, t2, q = centre_case(anim["objet"]), (EX - 30, EY - 120), 60, 36, p / 0.6

    def pos(u):
        u = u * u * (3 - 2 * u)
        return (depart[0] + (arrivee[0] - depart[0]) * u,
                depart[1] + (arrivee[1] - depart[1]) * u - math.sin(math.pi * u) * 100)

    for k in range(4, 0, -1):  # traînée d'étincelles
        px, py = pos(max(0, q - 0.05 * k))
        pygame.draw.circle(ecran, (255, 240, 150), (int(px), int(py)), 8 - k)
    x, y = pos(q)
    taille = int(t1 + (t2 - t1) * q)
    if genre == "soin":
        coeur(ecran, int(x), int(y), taille, (255, 80, 120))
    else:
        poser_objet(ecran, anim["objet"], int(x), int(y), taille)


def barre_de_vie(ecran, combat, t):
    """En haut, au milieu : le nom de l'ennemi, sa barre de vie et ce qu'il prépare (attaque normale ou GROS COUP)."""
    police = petite_police(20)
    largeur = 380
    x0, y0 = L // 2 - largeur // 2 - 20, 46
    voile(ecran, (x0 - 14, 8, largeur + 92, 74), 150, (10, 6, 12))
    nom = police.render(combat["nom"].capitalize(), True, (255, 235, 200))
    ecran.blit(nom, (x0, y0 - 30))
    pygame.draw.rect(ecran, (25, 18, 22), (x0 - 3, y0 - 3, largeur + 6, 24), border_radius=7)
    plein = int(largeur * max(0, combat["pv"]) / combat["pv_max"])
    if plein:
        pygame.draw.rect(ecran, (200, 40, 40), (x0, y0, plein, 18), border_radius=5)
        pygame.draw.rect(ecran, (255, 120, 110), (x0, y0, plein, 6), border_radius=3)
    for k in range(1, combat["pv_max"]):  # une petite marque par point de vie
        xx = x0 + largeur * k // combat["pv_max"]
        pygame.draw.line(ecran, (25, 18, 22), (xx, y0), (xx, y0 + 17), 3)
    texte = police.render(f"{max(0, combat['pv'])}/{combat['pv_max']}", True, (255, 235, 200))
    ecran.blit(texte, (x0 + largeur - texte.get_width(), y0 - 30))
    # l'intention : une épée (coup normal) ou un gros "!!" qui pulse (gros coup)
    ix, iy = x0 + largeur + 38, y0 + 8
    if combat["intention"] == "fort":
        r = 20 + int(abs(math.sin(t * 6)) * 5)
        pygame.draw.circle(ecran, (120, 10, 10), (ix, iy), r)
        pygame.draw.circle(ecran, (255, 80, 60), (ix, iy), r, 3)
        txt = police_grasse(22).render("!!", True, (255, 230, 120))
        ecran.blit(txt, txt.get_rect(center=(ix, iy)))
    else:
        pygame.draw.circle(ecran, (40, 34, 50), (ix, iy), 20)
        pygame.draw.circle(ecran, (170, 160, 190), (ix, iy), 20, 2)
        poser_objet(ecran, "épée", ix, iy, 30, -45)


TEXTES_ACTIONS = {"rencontre": ("Combattre (A)", "Surprendre (S)", "Fuir (F)"),
                  "combat": ("Attaquer (A)", "Parer (P)", "Potion (B)", "Fuir (F)")}
Y_BOUTONS = 662  # la rangée de boutons, en bas de la boîte de texte


def dessiner_actions(ecran, police, jeu):
    """Face à un ennemi : tes choix, en bas de l'écran (clic ou clavier)."""
    textes = TEXTES_ACTIONS[jeu["phase"]]
    n = len(textes)
    largeur = (L - 96 - (n - 1) * 16) // n
    for i, texte in enumerate(textes):
        grise = jeu["phase"] == "combat" and texte.startswith("Potion") and "potion" not in jeu["inv"]
        bouton(ecran, police, pygame.Rect(48 + i * (largeur + 16), Y_BOUTONS, largeur, 40), texte, i == jeu["choix_action"],
               touche=pygame.K_RETURN, champ="choix_action", valeur=i, grise=grise)


def dessiner_epreuve(ecran, police, moyenne, jeu, t):
    """Le panneau du mini-jeu, au-dessus de la salle : l'énigme, les pierres à runes ou la jauge de la fosse."""
    ep = jeu["epreuve"]
    panneau = pygame.Rect(240, 132, 800, 410)
    voile(ecran, panneau, 228, (12, 10, 20))
    pygame.draw.rect(ecran, (150, 130, 80), panneau, 3, border_radius=14)
    titre = moyenne.render(NOMS_EPREUVES[ep["jeu"]], True, (240, 200, 60))
    ecran.blit(titre, titre.get_rect(midtop=(panneau.centerx, panneau.y + 16)))
    souris = pygame.mouse.get_pos()
    if ep["debut"] is None:  # le mini-jeu commence quand le panneau apparaît
        ep["debut"] = t

    if ep["jeu"] == "enigme":
        y = panneau.y + 72
        for ligne in lignes_de_texte(ep["question"], police, panneau.width - 80):
            texte = police.render(ligne, True, (245, 240, 225))
            ecran.blit(texte, texte.get_rect(midtop=(panneau.centerx, y)))
            y += 28
        for i, reponse in enumerate(ep["choix"]):
            r = pygame.Rect(panneau.x + 110, panneau.y + 172 + i * 70, panneau.width - 220, 54)
            bouton(ecran, police, r, f"{i + 1}.  {reponse[0].upper() + reponse[1:]}", False,
                   action=lambda i=i: repondre_enigme(jeu, i))

    elif ep["jeu"] == "runes":
        allumee, etape, fini = rune_allumee(ep, t)
        if allumee is not None and ep.get("son_etape") != etape:  # un petit son à chaque pierre qui s'allume
            ep["son_etape"] = etape
            jouer_son("ami")
        consigne = "À toi ! Clique les pierres dans le même ordre." if fini else "Regarde bien l'ordre des pierres..."
        texte = police.render(consigne, True, (255, 235, 170) if fini else (210, 205, 225))
        ecran.blit(texte, texte.get_rect(midtop=(panneau.centerx, panneau.y + 70)))
        for i in range(4):
            cx, cy = panneau.centerx + int((i - 1.5) * 170), panneau.y + 215
            pierre = pygame.Rect(cx - 62, cy - 86, 124, 172)
            appui = ep["appui"] is not None and ep["appui"][0] == i and t - ep["appui"][1] < 0.35
            brille = allumee == i or appui
            survol = fini and pierre.collidepoint(souris)
            couleur = COULEURS_RUNES[i]
            if brille:
                ecran.blit(lueur(120, tuple(v // 2 for v in couleur)), (cx - 120, cy - 120), special_flags=pygame.BLEND_RGB_ADD)
            pygame.draw.rect(ecran, (96, 90, 106) if brille else (70, 65, 80), pierre, border_radius=22)
            pygame.draw.rect(ecran, (255, 215, 90) if survol else (40, 36, 48), pierre, 5 if survol else 3, border_radius=22)
            trait = couleur if brille else teinte(couleur, 0.45)
            for a, b in GLYPHES[i]:
                pygame.draw.line(ecran, trait, (cx + a[0] * 1.3, cy + a[1] * 1.3),
                                 (cx + b[0] * 1.3, cy + b[1] * 1.3), 8 if brille else 6)
            numero = police.render(str(i + 1), True, (170, 165, 185))
            ecran.blit(numero, numero.get_rect(midtop=(cx, pierre.bottom + 8)))
            if fini:
                zone(pierre, action=lambda i=i: toucher_rune(jeu, i))
        n = len(ep["suite"])  # une petite bille par pierre à retrouver
        for j in range(n):
            bx = panneau.centerx + int((j - (n - 1) / 2) * 32)
            pygame.draw.circle(ecran, (90, 230, 120) if j < len(ep["saisie"]) else (60, 55, 72), (bx, panneau.bottom - 26), 10)

    else:  # la fosse
        texte = police.render("Le bord est glissant... saute au bon moment !", True, (210, 205, 225))
        ecran.blit(texte, texte.get_rect(midtop=(panneau.centerx, panneau.y + 70)))
        jauge = pygame.Rect(panneau.x + 70, panneau.y + 150, panneau.width - 140, 52)
        pygame.draw.rect(ecran, (120, 40, 40), jauge, border_radius=10)
        verte = pygame.Rect(jauge.x + int((ep["centre"] - ep["largeur"] / 2) * jauge.w), jauge.y,
                            int(ep["largeur"] * jauge.w), jauge.h)
        pygame.draw.rect(ecran, (60, 190, 90), verte, border_radius=8)
        pygame.draw.rect(ecran, (150, 240, 160), verte, 3, border_radius=8)
        pygame.draw.rect(ecran, (40, 30, 30), jauge, 4, border_radius=10)
        cx = jauge.x + int(curseur_fosse(ep, t) * jauge.w)
        pygame.draw.line(ecran, (255, 255, 255), (cx, jauge.y - 10), (cx, jauge.bottom + 10), 5)
        pygame.draw.polygon(ecran, (255, 235, 140), [(cx - 13, jauge.y - 26), (cx + 13, jauge.y - 26), (cx, jauge.y - 8)])
        bouton(ecran, moyenne, pygame.Rect(panneau.centerx - 170, panneau.y + 250, 340, 74), "SAUTER !", True,
               action=lambda: sauter_fosse(jeu))
        aide = police.render("(ou barre Espace)", True, (150, 145, 170))
        ecran.blit(aide, aide.get_rect(midtop=(panneau.centerx, panneau.y + 336)))
    # sous la salle : passer l'épreuve
    bouton(ecran, police, pygame.Rect(L - 340, Y_BOUTONS, 292, 40), "Passer l'épreuve (F)", False, touche=pygame.K_f)


def dessiner_resultat(ecran, grande, anim, p):
    """RÉUSSI ! en vert avec des étincelles, ou RATÉ... en rouge, au centre de la salle."""
    reussi = anim["type"] == "reussite"
    texte = grande.render("RÉUSSI !" if reussi else "RATÉ...", True, (110, 240, 140) if reussi else (255, 90, 80))
    texte.set_alpha(int(255 * min(1, (1 - p) * 3)))
    ecran.blit(texte, texte.get_rect(center=(L // 2, 230 - int(26 * p))))
    if reussi:
        etincelles(ecran, L // 2, 230, p, (140, 255, 160), 12, 120 + 50 * p, 160 + 70 * p)

# ---------------------------------------------------------------- Programme
def construire_grotte(niveau):
    """Place les salles du niveau choisi au hasard sur la grille. Retourne (grotte, case de départ)."""
    modeles = {}
    for s in SALLES:
        modeles.setdefault(s.get("boss", s["type"]), []).append(s)
    salles = []
    for genre, nombre in NIVEAUX[niveau]["salles"].items():
        choix = modeles[genre][:]
        random.shuffle(choix)  # au hasard : par exemple, quelles épreuves on trouvera dans cette partie
        salles += [dict(choix[i % len(choix)]) for i in range(nombre)]
    random.shuffle(salles)
    cases = [(x, y) for y in range(GRILLE_H) for x in range(GRILLE_L)]
    grotte = dict(zip(cases, salles))
    depart = random.choice([c for c in cases if grotte[c]["type"] == "vide"])
    return grotte, depart


def nouvelle_partie(jeu):
    niveau = jeu["niveau"]
    grotte, depart = construire_grotte(niveau)
    classement = charger_classement(niveau)
    pv_max = NIVEAUX[niveau]["pv_max"]
    jeu.update(etat="jeu", inv=set(), coups=0, scene={"type": "entree"}, rang=None, pv=pv_max, pv_max=pv_max, anims=[],
               grotte=grotte, depart=depart, pos=depart, vus={depart}, carte=False, choix=0,
               precedent=depart, chemins=set(), phase="carrefour", rencontre=None, choix_action=0,
               epreuve=None, force=0, enigmes_vues=set(), combat=None,
               record=classement[0] if classement else None,
               msg=f"{jeu['nom']}, tu entres dans la grotte (niveau {NIVEAUX[niveau]['nom']}). "
                   "Clique sur une entrée (ou flèches du clavier) pour avancer. "
                   "Objectif : vaincre le dragon et sauver la princesse !")


def anim_courante(jeu, t):
    """Retourne (animation en cours, progression de 0 à 1), ou (None, 0). Passe à la suivante quand elle est finie."""
    while jeu["anims"]:
        a = jeu["anims"][0]
        if "debut" not in a:  # l'animation démarre : on joue son bruitage
            a["debut"] = t
            jouer_son(a.get("son"))
        p = (t - a["debut"]) / a["duree"]
        if p < 1:
            return a, p
        jeu["anims"].pop(0)
        if "apres" in a:
            a["apres"]()  # action à faire quand l'animation se termine
    return None, 0


NOMS_DIRECTION = {"gauche": "la gauche", "haut": "le haut", "droite": "la droite", "bas": "l'arrière"}


DEPLACEMENTS = {"gauche": (-1, 0), "droite": (1, 0), "haut": (0, -1), "bas": (0, 1)}


def avancer(jeu, direction):
    """Le chevalier marche vers la sortie choisie ; la salle suivante apparaît ensuite (voir entrer)."""
    jeu["coups"] += 1
    dx, dy = DEPLACEMENTS[direction]
    x, y = jeu["pos"]
    case = ((x + dx) % GRILLE_L, (y + dy) % GRILLE_H)  # la grotte est "ronde" : un bord ramène de l'autre côté
    jeu["msg"] = f"Tu t'avances vers {NOMS_DIRECTION[direction]}..."
    jeu["anims"].append({"type": "marche", "dir": direction, "duree": 0.55, "son": "pas",
                         "apres": lambda: entrer(jeu, direction, case)})


def entrer(jeu, direction, case):
    jeu["precedent"], jeu["pos"] = jeu["pos"], case
    jeu["vus"].add(case)
    jeu.setdefault("chemins", set()).add(frozenset((jeu["precedent"], case)))  # pour la carte
    salle = jeu["grotte"][case]
    jeu["phase"] = "carrefour"
    if salle["type"] in ENNEMIS and (salle["type"] != "voleur" or jeu["inv"]):
        # Un ennemi : il dort ou il t'a vu. À toi de choisir (combattre, surprendre ou fuir).
        dort = random.random() < NIVEAUX[jeu["niveau"]]["sommeil"]
        jeu["rencontre"] = {"dort": dort}
        jeu["phase"], jeu["choix_action"] = "rencontre", 0
        etat_ennemi = "\nIl dort profondément... Zzz" if dort else "\nIl t'a vu ! Il est sur ses gardes !"
        jeu["msg"] = salle["texte"] + etat_ennemi + "\nQue fais-tu ?"
        jeu["scene"] = {**salle, "dort": dort}
        if not dort:
            jouer_son({"dragon": "dragon", "gardien": "gardien"}.get(salle["type"]))
    elif salle["type"] == "epreuve" and not salle.get("fait"):
        jeu["msg"] = commencer_epreuve(jeu, salle)
        jeu["scene"] = salle
    else:
        resultat, jeu["msg"] = visiter(salle, jeu)
        jeu["scene"] = {**salle, "vaincu": True} if resultat == "voleur_parti" else salle
    jeu["anims"].insert(0, {"type": "arrivee", "dir": direction, "duree": 0.55})


def blesser(jeu, degats, y0=440, mortel=True):
    """Retire des coeurs (animation comprise). Si mortel, le chevalier peut tomber."""
    jeu["pv"] = jeu["pv"] - degats if mortel else max(1, jeu["pv"] - degats)
    jeu["anims"].append({"type": "degats", "duree": 0.8, "son": "degats", "montant": degats, "y0": y0})
    if jeu["pv"] <= 0:
        jeu["anims"].append({"type": "chute", "duree": 1.0, "son": "mort"})


def reculer(jeu):
    """Fin d'une fuite : le chevalier retombe dans la salle d'où il venait (rien ne s'y déclenche à nouveau)."""
    jeu["pos"] = jeu["precedent"]
    salle = jeu["grotte"][jeu["pos"]]
    jeu["scene"] = {**salle, "vaincu": True} if salle["type"] in ENNEMIS else salle
    jeu["phase"], jeu["combat"] = "carrefour", None
    jeu["msg"] = "Tu es de retour dans la salle précédente. Trois entrées s'offrent à toi."
    jeu["anims"].insert(0, {"type": "arrivee", "dir": "haut", "duree": 0.55})


# ---------------------------------------------------------------- Le combat au tour par tour
# pv : ses points de vie ; degats : ce que fait un coup normal (un GROS COUP fait le double)
STATS_ENNEMIS = {"squelette": {"nom": "le spectre", "pv": 3, "degats": 1, "son": "gardien"},
                 "troll": {"nom": "le troll", "pv": 4, "degats": 2, "son": "coup"},
                 "dragon": {"nom": "le dragon", "pv": 6, "degats": 2, "son": "dragon"}}
CHANCE_GROS_COUP = 0.35   # à chaque tour, l'ennemi a cette chance de préparer un gros coup
CHANCE_ESQUIVE = 0.1      # et celle-ci d'esquiver ton attaque
ANNONCES = {  # ce que tu vois l'ennemi préparer : (coup normal, GROS COUP)
    "squelette": ("Le spectre lève sa faux.", "Le spectre fait tournoyer sa faux : il prépare un GROS COUP !"),
    "troll": ("Le troll balance son gourdin.", "Le troll lève son gourdin très haut : il prépare un GROS COUP !"),
    "dragon": ("Le dragon montre les dents.", "Le dragon prend une grande inspiration : il va CRACHER DU FEU !"),
}
ACTIONS_COMBAT = ("attaquer", "parer", "potion", "fuir")


def nouvelle_intention(combat):
    """L'ennemi choisit son prochain coup. Tu le vois à l'avance : à toi de parer au bon moment !"""
    combat["intention"] = "fort" if random.random() < CHANCE_GROS_COUP else "normal"
    return ANNONCES[combat["genre"]][combat["intention"] == "fort"]


def commencer_combat(jeu, prefixe="", il_frappe_d_abord=False):
    case = jeu["pos"]
    salle = jeu["grotte"][case]
    genre = salle.get("boss", salle["type"])
    stats = STATS_ENNEMIS[genre]
    combat = {"genre": genre, "nom": stats["nom"], "pv_max": stats["pv"], "pv": salle.get("pv_restants", stats["pv"]),
              "degats": stats["degats"], "son": stats["son"], "bonus": jeu.pop("force", 0), "intention": "normal"}
    jeu["combat"] = combat
    jeu["phase"], jeu["choix_action"] = "combat", 0
    jeu["scene"] = {**salle, "dort": False, "combat": combat}
    msg = prefixe
    if il_frappe_d_abord:
        msg += ennemi_frappe(jeu, pare=False) + " "
    if jeu["pv"] <= 0:
        jeu["scene"]["mort"] = True
        return "mort", msg + "Tu t'effondres..."
    if not jeu.get("astuce_vue"):  # au premier combat de la partie, une petite astuce
        jeu["astuce_vue"] = True
        msg = "Astuce : quand l'ennemi prépare un GROS COUP (!!), clique sur Parer ! " + msg
    return "combat", msg + nouvelle_intention(combat)


def ennemi_frappe(jeu, pare):
    """Le tour de l'ennemi. Retourne la phrase qui raconte ce qui s'est passé."""
    combat, inv = jeu["combat"], jeu["inv"]
    fort = combat["intention"] == "fort"
    degats = combat["degats"] * (2 if fort else 1)
    nom = combat["nom"].capitalize()
    jeu["anims"].append({"type": "riposte", "duree": 0.9, "son": combat["son"], "pare": pare})
    if pare and "bouclier" in inv:
        combat["bonus"] = 1
        return f"{nom} frappe... mais tu PARES avec ton bouclier ! Ta prochaine attaque fera +1."
    if pare:
        degats //= 2
    if degats and "armure" in inv:
        degats = max(1, degats - 1)  # l'armure amortit le coup
    if degats:
        blesser(jeu, degats)
    if pare:
        return f"Sans bouclier, tu te protèges avec les bras : -{degats} PV seulement." if degats else "Tu évites le coup de justesse !"
    if fort:
        return f"{nom} t'assène un GROS COUP : -{degats} PV !"
    return f"{nom} te frappe : -{degats} PV."


def vaincre_ennemi(jeu, texte):
    """L'ennemi disparaît pour de bon (la carte se souvient de qui c'était)."""
    case = jeu["pos"]
    salle = jeu["grotte"][case]
    jeu["grotte"][case] = {"type": "vide", "texte": texte, "ancien": salle.get("boss", salle["type"])}
    jeu["scene"]["vaincu"] = True
    jeu["phase"], jeu["combat"] = "carrefour", None


def texte_vaincu(salle):
    if salle.get("boss") == "squelette":
        return "Il ne reste du spectre qu'un petit nuage de fumée bleue. Plus personne ne te barre la route."
    return "Le troll assommé ronfle par terre. Plus personne ne te barre la route."


def victoire_dragon(jeu, anims, texte):
    anims += [{"type": "mort_ennemi", "duree": 1.0, "son": "dragon"}, {"type": "bise", "duree": 3.0, "son": "victoire"}]
    return "victoire", texte + " Derrière lui, tu trouves la PRINCESSE : elle est sauvée !"


def boire_potion(jeu, anims):
    """La potion te téléporte à l'entrée de la grotte. L'ennemi garde ses blessures pour la prochaine fois."""
    jeu["inv"].discard("potion")
    if jeu.get("combat"):
        jeu["grotte"][jeu["pos"]]["pv_restants"] = jeu["combat"]["pv"]
    jeu["pos"] = jeu["precedent"] = jeu["depart"]
    jeu["phase"], jeu["combat"] = "carrefour", None

    def arrivee_entree():  # fin du nuage violet : on réapparaît dans la salle de départ
        jeu["scene"] = jeu["grotte"][jeu["depart"]]
        jeu["anims"].insert(0, {"type": "arrivee", "dir": "haut", "duree": 0.55})

    anims.append({"type": "teleport", "duree": 1.4, "son": "fuite", "apres": arrivee_entree})
    return "libre", "Tu bois ta potion : un nuage violet t'enveloppe et te téléporte à l'entrée de la grotte ! Ouf !"


def fuir(jeu, anims, dort, risque):
    """Tu fais demi-tour : si l'ennemi est réveillé, il peut te toucher dans le dos (ou te voler, pour le voleur)."""
    salle = jeu["grotte"][jeu["pos"]]
    if jeu.get("combat"):
        salle["pv_restants"] = jeu["combat"]["pv"]
    msg = "Tu fais demi-tour sans un bruit..." if dort else "Tu fais demi-tour en courant !"
    if not dort and random.random() < risque:
        if salle["type"] == "voleur":
            vole = random.choice(sorted(jeu["inv"]))
            jeu["inv"].remove(vole)
            anims.append({"type": "vol", "objet": vole, "duree": 1.6, "son": "vol"})
            jeu["scene"]["vaincu"] = True
            msg += f" Mais il t'arrache {vole} au passage !"
        else:
            blesser(jeu, DEGATS_FUITE)
            msg += f" Mais il te touche dans le dos : -{DEGATS_FUITE} PV."
    jeu["coups"] += 1  # fuir compte comme un déplacement
    anims.append({"type": "recul", "duree": 0.7, "son": "pas", "y0": KY, "apres": lambda: reculer(jeu)})
    if jeu["pv"] <= 0:
        anims.pop()  # il n'a plus la force de fuir
        jeu["scene"]["mort"] = True
        return "mort", msg + " Tu t'effondres..."
    return "recul", msg


def agir(jeu, action):
    """Face à un ennemi qui vient d'apparaître : combattre, surprendre ou fuir. Retourne (résultat, message)."""
    case = jeu["pos"]
    salle = jeu["grotte"][case]
    typ, inv, anims = salle["type"], jeu["inv"], jeu["anims"]
    dort = jeu["rencontre"]["dort"]
    jeu["phase"] = "carrefour"
    jeu["scene"] = scene = {**salle, "dort": dort}
    coup = {"type": "coup", "duree": 1.0, "son": "coup"}

    if action == "fuir":
        return fuir(jeu, anims, dort, RISQUE_FUITE)

    if typ == "voleur":  # le voleur ne se bat pas : il vole et il file
        if action == "surprendre" and dort:
            anims += [{"type": "approche", "duree": 0.9, "lent": True, "son": "pas"}, coup,
                      {"type": "mort_ennemi", "duree": 0.8}, {"type": "retour", "duree": 0.5, "x0": KX_COMBAT}]
            vaincre_ennemi(jeu, "Le voleur, ligoté, gît dans un coin. Il ne volera plus personne.")
            return "libre", "Tu assommes le voleur dans son sommeil ! Il ne volera plus personne."
        if action == "combattre" and "épée" in inv:
            anims += [coup, {"type": "fuit", "duree": 0.7}, {"type": "retour", "duree": 0.5, "x0": KX_COMBAT}]
            scene["vaincu"] = True
            return "libre", "Ton épée l'effraie : il s'enfuit sans rien prendre !"
        vole = random.choice(sorted(inv))
        inv.remove(vole)
        anims += [{"type": "vol", "objet": vole, "duree": 1.6, "son": "vol"}, {"type": "retour", "duree": 0.5, "x0": KX_COMBAT}]
        scene["vaincu"] = True
        debut = "Il t'a repéré avant que tu approches ! " if action == "surprendre" else ""
        return "libre", debut + f"Le voleur t'a pris : {vole} ! Il s'enfuit en riant."

    if action == "combattre":
        return commencer_combat(jeu, "Il se réveille en sursaut ! " if dort else "En garde ! ")
    # surprendre
    if not dort:  # il t'a vu : la surprise rate, et il frappe le premier
        return commencer_combat(jeu, "Il t'a repéré avant que tu approches ! ", il_frappe_d_abord=True)
    if "épée" not in inv:
        anims.append({"type": "recul", "duree": 0.7, "son": "pas", "y0": KY, "apres": lambda: reculer(jeu)})
        jeu["coups"] += 1
        return "recul", "Sans épée, tu ne peux rien contre lui. Tu repars sur la pointe des pieds."
    approche = {"type": "approche", "duree": 0.9, "lent": True, "son": "pas"}
    if typ == "gardien":
        anims += [approche, coup, {"type": "touche", "duree": 0.5, "montant": 9}, {"type": "mort_ennemi", "duree": 1.0},
                  {"type": "retour", "duree": 0.5, "x0": KX_COMBAT}]
        vaincre_ennemi(jeu, texte_vaincu(salle))
        return "libre", "Ton épée frappe avant qu'il ne s'éveille : il s'effondre, vaincu !"
    if SURPRISE_DRAGON.issubset(inv):
        anims += [approche, coup]
        return victoire_dragon(jeu, anims, "Tu t'approches sur la pointe des pieds et tu frappes le dragon endormi en plein coeur !")
    jouer_son("dragon")
    return commencer_combat(jeu, "Sans armure, la chaleur te fait reculer et ton pied heurte un caillou : le dragon se réveille ! ")


def tour_combat(jeu, action):
    """Un tour de combat : ton action, puis celle de l'ennemi. Retourne (résultat, message)."""
    combat, inv, anims = jeu["combat"], jeu["inv"], jeu["anims"]
    if action == "fuir":
        return fuir(jeu, anims, False, 0.5)
    if action == "potion":
        if "potion" not in inv:
            return "combat", "Tu n'as pas de potion ! " + ANNONCES[combat["genre"]][combat["intention"] == "fort"]
        return boire_potion(jeu, anims)
    if action == "attaquer":
        degats = (2 if "épée" in inv else (0 if combat["genre"] == "dragon" else 1)) + combat["bonus"]
        bonus, combat["bonus"] = combat["bonus"], 0
        anims.append({"type": "coup", "duree": 1.0, "son": "coup"})
        if random.random() < CHANCE_ESQUIVE:
            msg = f"{combat['nom'].capitalize()} esquive ton coup ! "
        elif degats == 0:
            msg = "Sans épée, tes coups ne lui font rien ! "
        else:
            combat["pv"] -= degats
            anims.append({"type": "touche", "duree": 0.5, "montant": degats})
            msg = ("CONTRE-ATTAQUE ! " if bonus else "") + f"Tu le touches : -{degats} PV. "
        if combat["pv"] <= 0:
            if combat["genre"] == "dragon":
                return victoire_dragon(jeu, anims, msg + "Le dragon s'effondre !")
            anims += [{"type": "mort_ennemi", "duree": 1.0}, {"type": "retour", "duree": 0.5, "x0": KX_COMBAT}]
            vaincre_ennemi(jeu, texte_vaincu(jeu["grotte"][jeu["pos"]]))
            return "libre", msg + f"{combat['nom'].capitalize()} est vaincu !"
        msg += ennemi_frappe(jeu, pare=False)
    else:  # parer
        msg = ennemi_frappe(jeu, pare=True)
    if jeu["pv"] <= 0:
        jeu["scene"]["mort"] = True
        return "mort", msg + " Tu t'effondres..."
    return "combat", msg + "\n" + nouvelle_intention(combat)


def faire_action(jeu, action):
    resultat, msg = tour_combat(jeu, action) if jeu["phase"] == "combat" else agir(jeu, action)
    jeu["msg"] = msg
    if resultat == "victoire":
        jeu["rang"] = enregistrer(jeu["nom"], jeu["coups"], jeu["niveau"])
        jeu["etat"] = "victoire"
        record = " NOUVEAU RECORD !" if jeu["rang"] == 1 else ""
        jeu["msg"] += f"\nBravo {jeu['nom']} : {jeu['coups']} coups, tu es n°{jeu['rang']} !{record} (clic ou Entrée : classement)"
    elif resultat == "mort":
        jeu["etat"] = "mort"


# ---------------------------------------------------------------- Boutons et clics de souris
# Chaque bouton dessiné s'inscrit ici : quand on clique dessus, c'est comme si on appuyait sur sa touche.
ZONES = []


def zone(rect, touche=None, champ=None, valeur=None, action=None):
    ZONES.append({"rect": pygame.Rect(rect), "touche": touche, "champ": champ, "valeur": valeur, "action": action})


def zone_sous(pos):
    for z in reversed(ZONES):  # la dernière dessinée est au-dessus des autres
        if z["rect"].collidepoint(pos):
            return z
    return None


def bouton(ecran, police, rect, texte, actif, touche=None, champ=None, valeur=None, grise=False, action=None):
    survol = rect.collidepoint(pygame.mouse.get_pos())
    if grise:
        fond_, bord, couleur, epaisseur = (28, 25, 34), (70, 64, 82), (95, 90, 105), 2
    elif actif or survol:
        fond_, bord, couleur, epaisseur = (120, 30, 30), (255, 215, 90), (255, 255, 255), 4
    else:
        fond_, bord, couleur, epaisseur = (35, 30, 45), (110, 100, 130), (190, 185, 205), 2
    pygame.draw.rect(ecran, fond_, rect, border_radius=12)
    pygame.draw.rect(ecran, bord, rect, epaisseur, border_radius=12)
    etiquette = police.render(texte, True, couleur)
    ecran.blit(etiquette, etiquette.get_rect(center=rect.center))
    if not grise and (touche is not None or action is not None):  # un bouton grisé ne se clique pas
        zone(rect, touche, champ, valeur, action)


def lignes_de_texte(texte, police, largeur):
    lignes = []
    for para in texte.split("\n"):
        courante = ""
        for mot in para.split():
            essai = (courante + " " + mot).strip()
            if police.size(essai)[0] <= largeur:
                courante = essai
            else:
                lignes.append(courante)
                courante = mot
        lignes.append(courante)
    return lignes


def dessiner_interface(ecran, police, inv, nom, coups, message, pv, cache=None, record=None, pv_max=4, lignes_max=5):
    """Le haut de l'écran (inventaire, coeurs, score, boutons Carte et Son) et la boîte de texte en bas."""
    voile(ecran, (0, 0, L, 150), 110, (8, 5, 12))  # une bande sombre en haut : tout reste lisible sur le décor
    for i, obj in enumerate(OBJETS):  # inventaire en haut à gauche
        case = pygame.Rect(16 + i * 80, 16, 72, 72)
        pygame.draw.rect(ecran, (25, 22, 35), case, border_radius=10)
        pygame.draw.rect(ecran, (150, 130, 80) if obj in inv and obj != cache else (90, 80, 115), case, 2, border_radius=10)
        img = image_echelle(IMAGES_OBJETS[obj], 60 / max(objet_surface(obj).get_size()))
        if obj not in inv or obj == cache:
            img = img.copy()
            img.set_alpha(45)  # objet pas encore possédé : grisé
        ecran.blit(img, img.get_rect(center=case.center))
    for i in range(pv_max):  # points de vie
        coeur(ecran, 32 + i * 36, 114, 12, (230, 50, 80) if i < pv else (70, 60, 85))
    info = police.render(f"{nom}  -  Coups : {coups}", True, (240, 230, 200))
    ecran.blit(info, (L - info.get_width() - 20, 18))
    texte_record = f"Record : {record['coups']} coups ({record['nom']})" if record else "Record : à battre !"
    rec = police.render(texte_record, True, (240, 200, 60))
    ecran.blit(rec, (L - rec.get_width() - 20, 50))
    petite = petite_police(18)  # deux petits boutons : la carte et le son
    bouton(ecran, petite, pygame.Rect(L - 340, 88, 154, 34), "Carte (C)", False, touche=pygame.K_c)
    bouton(ecran, petite, pygame.Rect(L - 176, 88, 156, 34), "Son " + ("oui" if SON_ACTIF else "non") + " (M)", False,
           touche=pygame.K_m)
    boite = pygame.Rect(20, HAUT_SCENE + 10, L - 40, H - HAUT_SCENE - 18)
    pygame.draw.rect(ecran, (20, 18, 30), boite, border_radius=14)
    pygame.draw.rect(ecran, (150, 130, 80), boite, 3, border_radius=14)
    for i, ligne in enumerate(lignes_de_texte(message, police, boite.width - 40)[:lignes_max]):
        ecran.blit(police.render(ligne, True, (245, 240, 225)), (boite.x + 20, boite.y + 12 + i * 25))


def dessiner_game_over(ecran, moyenne, enorme, police, choix):
    """Gros GAME OVER rouge, puis le choix Rejouer / Menu / Quitter."""
    voile(ecran, (0, 140, L, 300), 175)
    titre = enorme.render("GAME OVER", True, (225, 30, 30))
    x = (L - titre.get_width()) // 2
    ecran.blit(enorme.render("GAME OVER", True, (50, 0, 0)), (x + 5, 160))  # ombre
    ecran.blit(titre, (x, 155))
    for i, (texte, r) in enumerate(zip(MENU_FIN, rangee_boutons(len(MENU_FIN), 220, 24, 320, 60))):
        bouton(ecran, moyenne, r, texte, i == choix, touche=pygame.K_RETURN, champ="choix", valeur=i)
    aide = police.render("Clique, ou gauche / droite puis Entrée", True, (200, 195, 215))
    ecran.blit(aide, ((L - aide.get_width()) // 2, 400))


def ecran_titre(ecran, t, police, moyenne, grande, choix):
    """Écran d'accueil : l'image du dragon sur sa grotte, le titre et le menu."""
    dessiner_fond(ecran, "fond_titre", t)
    titre = police_grasse(58)
    texte_ombre(ecran, titre, "SAUVE", (250, 205, 60), centre=(1010, 200), decalage=4)
    texte_ombre(ecran, titre, "LA PRINCESSE", (250, 205, 60), centre=(1010, 268), decalage=4)
    voile(ecran, (0, 560, L, 160), 170, (8, 4, 12))
    sous = police.render("Trouve ton équipement, affronte le dragon et ne te fais pas voler !", True, (230, 220, 200))
    ecran.blit(sous, ((L - sous.get_width()) // 2, 574))
    for i, (texte, r) in enumerate(zip(MENU_TITRE, rangee_boutons(len(MENU_TITRE), 240, 24, 612, 58))):
        bouton(ecran, moyenne, r, texte, i == choix, touche=pygame.K_RETURN, champ="choix", valeur=i)
    aide = police.render("Clique, ou gauche / droite puis Entrée", True, (170, 165, 190))
    ecran.blit(aide, ((L - aide.get_width()) // 2, 684))


def ecran_nom(ecran, t, police, moyenne, grande, jeu):
    dessiner_fond(ecran, "fond_titre", t)
    voile(ecran, (0, 0, L, H), 120, (8, 4, 12))
    texte_ombre(ecran, police_grasse(56), "SAUVE LA PRINCESSE", (250, 205, 60), centre=(L // 2, 80), decalage=4)
    voile(ecran, (0, 440, L, 280), 170, (8, 4, 12))
    ecran.blit(police.render("Quel est le nom de ton chevalier ?", True, (240, 230, 200)), (220, 478))
    champ = pygame.Rect(220, 520, 540, 66)
    pygame.draw.rect(ecran, (20, 18, 30), champ, border_radius=12)
    pygame.draw.rect(ecran, (150, 130, 80), champ, 3, border_radius=12)
    ecran.blit(grande.render(jeu["nom"] + ("|" if int(t * 2) % 2 == 0 else ""), True, (255, 255, 255)),
               (champ.x + 18, champ.y + 6))
    bouton(ecran, moyenne, pygame.Rect(790, 520, 270, 66), "C'est parti !", True, touche=pygame.K_RETURN)
    clavier_ecran(ecran, moyenne, police, jeu)


# Le clavier à l'écran (AZERTY) : pour écrire son nom au doigt sur téléphone, ou à la souris
RANGEES_CLAVIER = ("AZERTYUIOP", "QSDFGHJKLM", "WXCVBN")


def taper_lettre(jeu, lettre):
    if lettre == "<":
        jeu["nom"] = jeu["nom"][:-1]
    elif len(jeu["nom"]) < 14:
        jeu["nom"] += lettre if not jeu["nom"] or jeu["nom"].endswith(" ") else lettre.lower()
    jouer_son("clic")


def clavier_ecran(ecran, moyenne, police, jeu):
    voile(ecran, (200, 172, 880, 262), 150, (8, 4, 12))
    for r, rangee in enumerate(RANGEES_CLAVIER):
        for i, lettre in enumerate(rangee):
            rect = pygame.Rect(220 + i * 84, 184 + r * 80, 76, 64)
            bouton(ecran, moyenne, rect, lettre, False, action=lambda c=lettre: taper_lettre(jeu, c))
    bouton(ecran, police, pygame.Rect(220 + 6 * 84, 344, 76 * 2 + 8, 64), "Espace", False,
           action=lambda: taper_lettre(jeu, " "))
    bouton(ecran, police, pygame.Rect(220 + 8 * 84, 344, 76 * 2 + 8, 64), "Effacer", False,
           action=lambda: taper_lettre(jeu, "<"))


MENU_TITRE = ("Jouer", "Classement") + (() if WEB else ("Quitter",))
MENU_FIN = ("Rejouer", "Menu") + (() if WEB else ("Quitter",))


def rangee_boutons(nombre, largeur, ecart, y, hauteur):
    """Des boutons côte à côte, centrés dans la fenêtre."""
    x0 = (L - nombre * largeur - (nombre - 1) * ecart) // 2
    return [pygame.Rect(x0 + i * (largeur + ecart), y, largeur, hauteur) for i in range(nombre)]


COULEURS_NIVEAUX = {"facile": (90, 200, 120), "normal": (240, 200, 60), "difficile": (230, 80, 70)}


def fond_menu(ecran, t):
    """Le fond des écrans de menu : la salle de la grotte, assombrie."""
    dessiner_fond(ecran, "fond_salle", t)
    voile(ecran, (0, 0, L, H), 175, (10, 8, 16))


def ecran_niveau(ecran, police, moyenne, grande, jeu):
    """Choix de la difficulté : trois cartes."""
    fond_menu(ecran, pygame.time.get_ticks() / 1000)
    titre = grande.render("CHOISIS TA DIFFICULTÉ", True, (240, 200, 60))
    ecran.blit(titre, ((L - titre.get_width()) // 2, 24))
    sous = police.render(f"{jeu['nom']}, quel genre de chevalier es-tu ?", True, (210, 200, 180))
    ecran.blit(sous, ((L - sous.get_width()) // 2, 92))
    souris = pygame.mouse.get_pos()
    for i, (niveau, carte) in enumerate(zip(ORDRE_NIVEAUX, rangee_boutons(3, 360, 40, 140, 410))):
        cfg, couleur = NIVEAUX[niveau], COULEURS_NIVEAUX[niveau]
        actif = i == jeu["choix"] or carte.collidepoint(souris)
        zone(carte, pygame.K_RETURN, "choix", i)
        pygame.draw.rect(ecran, (55, 48, 75) if actif else (38, 33, 52), carte, border_radius=16)
        pygame.draw.rect(ecran, couleur if actif else (90, 82, 110), carte, 5 if actif else 2, border_radius=16)
        nom = moyenne.render(cfg["nom"].upper(), True, couleur)
        ecran.blit(nom, (carte.centerx - nom.get_width() // 2, carte.y + 18))
        desc = police.render(cfg["desc"], True, (210, 205, 225))
        ecran.blit(desc, (carte.centerx - desc.get_width() // 2, carte.y + 72))
        for k in range(cfg["pv_max"]):  # les coeurs de départ
            coeur(ecran, carte.centerx - (cfg["pv_max"] - 1) * 18 + k * 36, carte.y + 128, 12, (230, 50, 80))
        s = cfg["salles"]
        lignes = (f"{s['voleur']} voleurs", f"{s['squelette'] + s['troll']} mini-boss", f"{s['coeur']} sources de vie",
                  f"{s['epreuve']} épreuves")
        for j, ligne in enumerate(lignes):
            ecran.blit(police.render(ligne, True, (235, 230, 245)), (carte.x + 40, carte.y + 168 + j * 32))
        record = jeu["records"].get(niveau)
        ecran.blit(police.render("Record", True, (240, 200, 60)), (carte.x + 40, carte.y + 314))
        texte = f"{record['coups']} coups ({record['nom'][:12]})" if record else "pas encore de record"
        ecran.blit(police.render(texte, True, (235, 230, 245)), (carte.x + 40, carte.y + 346))
    bouton(ecran, police, pygame.Rect(60, 582, 200, 50), "< Retour", False, touche=pygame.K_ESCAPE)
    aide = police.render("Clique sur une carte, ou gauche / droite puis Entrée", True, (160, 155, 180))
    ecran.blit(aide, ((L - aide.get_width()) // 2, 680))


def medaille(ecran, police, centre, rang):
    """Médaille d'or, d'argent ou de bronze."""
    couleur = {1: (255, 205, 60), 2: (205, 210, 220), 3: (205, 127, 50)}[rang]
    pygame.draw.circle(ecran, (60, 40, 10), centre, 21)
    pygame.draw.circle(ecran, couleur, centre, 18)
    pygame.draw.circle(ecran, tuple(min(255, c + 45) for c in couleur), (centre[0] - 6, centre[1] - 6), 6)
    chiffre = police.render(str(rang), True, (60, 40, 10))
    ecran.blit(chiffre, chiffre.get_rect(center=(centre[0] + 1, centre[1] + 2)))


def ouvrir_classement(jeu, niveau, retour):
    jeu.update(etat="classement", niveau_cl=niveau, retour=retour, liste=charger_classement(niveau))


def ecran_classement(ecran, police, moyenne, grande, jeu):
    """Classement d'un niveau : médailles pour les trois premiers, ta place en doré."""
    fond_menu(ecran, pygame.time.get_ticks() / 1000)
    titre = grande.render("CLASSEMENT", True, (240, 200, 60))
    ecran.blit(titre, ((L - titre.get_width()) // 2, 18))
    souris = pygame.mouse.get_pos()
    for i, (niveau, onglet) in enumerate(zip(ORDRE_NIVEAUX, rangee_boutons(3, 200, 20, 92, 46))):  # onglets cliquables
        actif = niveau == jeu["niveau_cl"]
        survol = onglet.collidepoint(souris)
        zone(onglet, action=lambda n=niveau: ouvrir_classement(jeu, n, jeu["retour"]))
        pygame.draw.rect(ecran, (60, 52, 82) if actif or survol else (38, 33, 52), onglet, border_radius=12)
        pygame.draw.rect(ecran, COULEURS_NIVEAUX[niveau] if actif else (90, 82, 110), onglet, 3 if actif else 1,
                         border_radius=12)
        etiquette = police.render(NIVEAUX[niveau]["nom"], True, COULEURS_NIVEAUX[niveau] if actif else (170, 165, 185))
        ecran.blit(etiquette, etiquette.get_rect(center=onglet.center))
    if not jeu["liste"]:
        vide = police.render("Aucun chevalier n'a encore sauvé la princesse à ce niveau.", True, (200, 195, 215))
        ecran.blit(vide, ((L - vide.get_width()) // 2, 320))
    for i, j in enumerate(jeu["liste"][:8], start=1):
        y = 158 + (i - 1) * 52
        ligne = pygame.Rect(240, y, 800, 46)
        pygame.draw.rect(ecran, (62, 54, 84) if i <= 3 else (42, 37, 58), ligne, border_radius=10)
        if jeu.get("rang") == i and jeu["retour"] == "rejouer" and jeu["niveau_cl"] == jeu["niveau"]:
            pygame.draw.rect(ecran, (255, 215, 90), ligne, 3, border_radius=10)  # ta place
        police_ligne = moyenne if i <= 3 else police
        if i <= 3:
            medaille(ecran, police, (280, y + 23), i)
        else:
            numero = police.render(str(i), True, (170, 165, 185))
            ecran.blit(numero, numero.get_rect(center=(280, y + 24)))
        couleur = (255, 235, 170) if i == 1 else (235, 230, 245)
        nom = police_ligne.render(j["nom"], True, couleur)
        coups = police_ligne.render(f"{j['coups']} coups", True, couleur)
        ecran.blit(nom, (330, y + (46 - nom.get_height()) // 2))
        ecran.blit(coups, (1010 - coups.get_width(), y + (46 - coups.get_height()) // 2))
    if jeu["retour"] == "titre":
        bouton(ecran, police, pygame.Rect(520, 604, 240, 52), "Retour au menu", False, touche=pygame.K_RETURN)
    else:
        bouton(ecran, police, pygame.Rect(390, 604, 240, 52), "Rejouer", True, touche=pygame.K_RETURN)
        bouton(ecran, police, pygame.Rect(650, 604, 240, 52), "Menu", False, touche=pygame.K_ESCAPE)
    aide = police.render("Clique sur un onglet, ou gauche / droite pour changer de niveau", True, (160, 155, 180))
    ecran.blit(aide, ((L - aide.get_width()) // 2, 682))


def dessiner_jeu(ecran, jeu, t, anim, p, police, moyenne, grande, enorme):
    """Une image du jeu : la salle, l'interface, les boutons, la carte et le GAME OVER."""
    etat = jeu["etat"]
    scene = {"type": "victoire"} if etat == "victoire" and not anim else jeu["scene"]
    tremble = 0  # l'écran tremble quand on est touché ou quand l'épée frappe
    if anim and anim["type"] == "degats":
        tremble = int(math.sin(p * 55) * 12 * (1 - p))
    elif anim and anim["type"] == "coup" and 0.45 < p < 0.7:
        tremble = int(math.sin(p * 90) * 7)
    elif anim and anim["type"] == "riposte" and 0.45 < p < 0.7:
        tremble = int(math.sin(p * 80) * 8)
    if tremble:  # on dessine la salle sur une feuille, que l'on pose un peu décalée
        feuille = _caches.setdefault("feuille_scene", pygame.Surface((L, H)))
        dessiner_scene(feuille, scene, jeu["inv"], t, anim, p)
        ecran.fill((10, 8, 14))
        ecran.blit(feuille, (tremble, 0))
    else:
        dessiner_scene(ecran, scene, jeu["inv"], t, anim, p)
    if etat == "jeu" and not anim and not jeu["carte"] and jeu["phase"] == "carrefour":
        dessiner_sorties(ecran, police, t)  # tes choix de sortie (cliquables)
    alpha = 80 if etat == "mort" else 0
    if anim and anim["type"] == "degats":
        alpha = max(alpha, int(140 * (1 - p)))  # flash rouge quand on est touché
    if alpha:
        voile(ecran, (0, 0, L, HAUT_SCENE), alpha // 10 * 10, (200, 0, 0))
    if anim and anim["type"] in ("marche", "arrivee", "recul", "teleport"):  # fondu noir entre deux salles
        if anim["type"] == "teleport":
            sombre = max(0.0, (p - 0.6) / 0.4) ** 2  # le noir arrive à la fin du nuage
        elif anim["type"] == "arrivee":
            sombre = (1 - p) ** 2
        else:
            sombre = p * p
        noir = _caches.setdefault("voile_noir", pygame.Surface((L, H)))
        noir.set_alpha(int(255 * sombre))
        ecran.blit(noir, (0, 0))
    cache = anim["objet"] if anim and anim["type"] == "don" else None
    pv_affiche = jeu["pv"] - 1 if anim and anim["type"] == "soin" else jeu["pv"]  # le coeur arrive en volant
    choix_en_cours = etat == "jeu" and jeu["phase"] in ("rencontre", "combat", "epreuve") and not anim
    dessiner_interface(ecran, police, jeu["inv"], jeu["nom"], jeu["coups"], jeu["msg"], pv_affiche, cache,
                       jeu["record"], jeu["pv_max"], 3 if choix_en_cours else 5)
    if jeu["scene"].get("combat") and ennemi_visible(jeu["scene"], anim["type"] if anim else None) \
            and not (anim and anim["type"] == "mort_ennemi") and etat == "jeu":
        barre_de_vie(ecran, jeu["scene"]["combat"], t)
    if jeu.get("force"):  # la pierre de force : +1 au prochain coup
        force = petite_police(18).render("Force +1", True, (255, 215, 90))
        ecran.blit(force, (26 + jeu["pv_max"] * 36, 104))
    if choix_en_cours and not jeu["carte"]:
        if jeu["phase"] == "epreuve":
            dessiner_epreuve(ecran, police, moyenne, jeu, t)
        else:
            dessiner_actions(ecran, police, jeu)
    if anim and anim["type"] in ("reussite", "rate"):
        dessiner_resultat(ecran, grande, anim, p)
    if anim and anim["type"] in ("don", "vol", "soin"):
        dessiner_vol_objet(ecran, anim, p)
    if anim and anim.get("montant"):  # chiffre qui monte : -2 en rouge, +1 en vert, dégâts sur l'ennemi en orange
        if anim["type"] == "degats":
            signe, couleur = "-", (255, 70, 70)
            x = KX_COMBAT if ennemi_visible(jeu["scene"], "degats") else KX_CENTRE
            centre = (x + 120, 300 - int(70 * p))
        elif anim["type"] == "touche":
            signe, couleur, centre = "-", (255, 170, 60), (EX + 110, 210 - int(70 * p))
        else:
            signe, couleur, centre = "+", (90, 230, 120), (KX_CENTRE + 120, 300 - int(70 * p))
        texte = "K.O." if anim["montant"] >= 9 else f"{signe}{anim['montant']}"
        chiffre = grande.render(texte, True, couleur)
        chiffre.set_alpha(int(255 * (1 - p)))
        ecran.blit(chiffre, chiffre.get_rect(center=centre))
    if anim and anim["type"] == "riposte" and anim.get("pare") and "bouclier" in jeu["inv"] and p > 0.45:
        pare = moyenne.render("PARÉ !", True, (150, 210, 255))
        pare.set_alpha(int(255 * min(1, (1 - p) * 3)))
        ecran.blit(pare, pare.get_rect(center=(KX_COMBAT, 210 - int(30 * p))))
    if etat == "victoire" and not anim:
        zone((0, 0, L, H), pygame.K_RETURN)  # un clic n'importe où : le classement
    if jeu["carte"]:
        dessiner_carte(ecran, police, jeu)
        zone((0, 0, L, H), pygame.K_c)  # un clic n'importe où ferme la carte
    if etat == "mort" and not anim:
        dessiner_game_over(ecran, moyenne, enorme, police, jeu["choix"])

async def main():
    global SON_ACTIF
    pygame.init()
    init_sons()
    ecran = pygame.display.set_mode((L, H))
    pygame.display.set_caption("Sauve la princesse")
    horloge = pygame.time.Clock()
    charger_images()
    police = pygame.font.SysFont("georgia,dejavusans,arial", 22)
    moyenne = pygame.font.SysFont("georgia,dejavusans,arial", 32, bold=True)
    grande = pygame.font.SysFont("georgia,dejavusans,arial", 46, bold=True)
    enorme = pygame.font.SysFont("georgia,dejavusans,arial", 120, bold=True)
    voir_fps = False
    jeu = {"etat": "titre", "nom": "", "niveau": "normal", "choix": 0}
    DIRECTIONS = {pygame.K_LEFT: "gauche", pygame.K_g: "gauche", pygame.K_RIGHT: "droite",
                  pygame.K_d: "droite", pygame.K_UP: "haut", pygame.K_h: "haut",
                  pygame.K_DOWN: "bas", pygame.K_b: "bas"}
    GAUCHE = (pygame.K_LEFT, pygame.K_UP, pygame.K_g)  # dans les menus
    DROITE = (pygame.K_RIGHT, pygame.K_DOWN, pygame.K_d)
    RACCOURCIS = {"rencontre": {pygame.K_a: 0, pygame.K_s: 1, pygame.K_f: 2},       # Combattre, Surprendre, Fuir
                  "combat": {pygame.K_a: 0, pygame.K_p: 1, pygame.K_b: 2, pygame.K_f: 3}}  # Attaquer, Parer, Potion, Fuir

    def quitter():
        if WEB:  # dans le navigateur, on ne ferme pas : on revient au menu (on ferme l'onglet pour quitter)
            vers_titre()
            return
        pygame.quit()
        sys.exit()

    def vers_titre():
        jeu.update(etat="titre", choix=0)

    def deplacer_choix(ev, nombre):
        if ev.key in GAUCHE:
            jeu["choix"] = max(0, jeu["choix"] - 1)
        elif ev.key in DROITE:
            jeu["choix"] = min(nombre - 1, jeu["choix"] + 1)

    while True:
        t = pygame.time.get_ticks() / 1000
        jeu["t"] = t  # les mini-jeux en ont besoin (runes, fosse)
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                quitter()
            if ev.type == pygame.MOUSEMOTION:  # la souris survole un bouton : il devient le choix en cours
                z = zone_sous(ev.pos)
                if z and z["champ"]:
                    jeu[z["champ"]] = z["valeur"]
                continue
            if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:  # un clic = la touche du bouton
                z = zone_sous(ev.pos)
                if not z:
                    continue
                if z["champ"]:
                    jeu[z["champ"]] = z["valeur"]
                if z["action"]:
                    z["action"]()
                    continue
                ev = pygame.event.Event(pygame.KEYDOWN, key=z["touche"], unicode="", mod=0)
            if ev.type != pygame.KEYDOWN:
                continue
            etat = jeu["etat"]
            entree = ev.key == pygame.K_RETURN
            if ev.key == pygame.K_ESCAPE:  # Échap : revenir au menu (ou quitter si on y est déjà)
                if etat == "titre":
                    quitter()
                vers_titre()
            elif ev.key == pygame.K_m and etat != "nom":
                SON_ACTIF = not SON_ACTIF  # M : son oui / non
            elif ev.key == pygame.K_i and etat != "nom":
                voir_fps = not voir_fps  # I : afficher les images par seconde
            elif ev.key == pygame.K_c and etat in ("jeu", "victoire", "mort"):
                jeu["carte"] = not jeu["carte"]  # C : carte de la grotte
            elif etat == "titre":
                deplacer_choix(ev, len(MENU_TITRE))
                if entree:
                    if jeu["choix"] == 0:
                        jeu["etat"] = "nom"
                    elif jeu["choix"] == 1:
                        ouvrir_classement(jeu, jeu["niveau"], "titre")
                    else:
                        quitter()
            elif etat == "nom":
                if entree:
                    jeu["nom"] = jeu["nom"].strip() or "Chevalier"
                    jeu["records"] = {n: (charger_classement(n) or [None])[0] for n in ORDRE_NIVEAUX}
                    jeu.update(etat="niveau", choix=ORDRE_NIVEAUX.index(jeu["niveau"]))
                elif ev.key == pygame.K_BACKSPACE:
                    jeu["nom"] = jeu["nom"][:-1]
                elif ev.unicode and ev.unicode.isprintable() and len(jeu["nom"]) < 14:
                    jeu["nom"] += ev.unicode
            elif etat == "niveau":
                deplacer_choix(ev, 3)
                if entree:
                    jeu["niveau"] = ORDRE_NIVEAUX[jeu["choix"]]
                    nouvelle_partie(jeu)
            elif etat == "jeu" and not jeu["anims"] and jeu["phase"] == "carrefour" and ev.key in DIRECTIONS:
                jeu["carte"] = False  # la carte se ferme quand on avance
                avancer(jeu, DIRECTIONS[ev.key])
            elif etat == "jeu" and not jeu["anims"] and jeu["phase"] == "epreuve":
                touche_epreuve(jeu, ev)
            elif etat == "jeu" and not jeu["anims"] and jeu["phase"] in ("rencontre", "combat"):
                raccourcis = RACCOURCIS[jeu["phase"]]
                nombre = len(raccourcis)
                if ev.key in raccourcis:
                    jeu["choix_action"] = raccourcis[ev.key]
                    entree = True
                elif ev.key in GAUCHE:
                    jeu["choix_action"] = max(0, jeu["choix_action"] - 1)
                elif ev.key in DROITE:
                    jeu["choix_action"] = min(nombre - 1, jeu["choix_action"] + 1)
                if entree:
                    jeu["carte"] = False
                    actions = ACTIONS_COMBAT if jeu["phase"] == "combat" else ACTIONS
                    faire_action(jeu, actions[min(jeu["choix_action"], nombre - 1)])
            elif etat == "victoire" and entree and not jeu["anims"]:
                ouvrir_classement(jeu, jeu["niveau"], "rejouer")
            elif etat == "mort" and not jeu["anims"]:
                deplacer_choix(ev, len(MENU_FIN))
                if ev.key == pygame.K_r or (entree and jeu["choix"] == 0):
                    nouvelle_partie(jeu)
                elif ev.key == pygame.K_q or (entree and jeu["choix"] == 2):
                    quitter()
                elif entree and jeu["choix"] == 1:
                    vers_titre()
            elif etat == "classement":
                if ev.key in GAUCHE or ev.key in DROITE:
                    i = ORDRE_NIVEAUX.index(jeu["niveau_cl"]) + (-1 if ev.key in GAUCHE else 1)
                    ouvrir_classement(jeu, ORDRE_NIVEAUX[i % len(ORDRE_NIVEAUX)], jeu["retour"])
                elif entree:
                    if jeu["retour"] == "titre":
                        vers_titre()
                    else:
                        nouvelle_partie(jeu)

        ZONES.clear()  # les boutons se réinscrivent en se dessinant
        etat = jeu["etat"]
        if etat == "titre":
            ecran_titre(ecran, t, police, moyenne, grande, jeu["choix"])
        elif etat == "nom":
            ecran_nom(ecran, t, police, moyenne, grande, jeu)
        elif etat == "niveau":
            ecran_niveau(ecran, police, moyenne, grande, jeu)
        elif etat == "classement":
            ecran_classement(ecran, police, moyenne, grande, jeu)
        else:
            anim, p = anim_courante(jeu, t)
            dessiner_jeu(ecran, jeu, t, anim, p, police, moyenne, grande, enorme)
        if voir_fps:  # touche I : combien d'images par seconde (60 = parfait, moins de 30 = ça rame)
            fps = horloge.get_fps()
            couleur = (90, 230, 120) if fps >= 50 else (240, 200, 60) if fps >= 30 else (255, 70, 70)
            texte = police.render(f"{fps:.0f} FPS", True, couleur)
            ecran.fill((0, 0, 0), texte.get_rect(topleft=(10, HAUT_SCENE - 34)).inflate(10, 4))
            ecran.blit(texte, (10, HAUT_SCENE - 34))
        pygame.display.flip()
        horloge.tick(60)
        await asyncio.sleep(0)  # on laisse le navigateur afficher l'image (sur PC, ça ne change rien)


if __name__ == "__main__":
    asyncio.run(main())
